#!/data/data/com.termux/files/usr/bin/bash
# SmokeBoy v3.7.1 - Termux auto setup (run once):  bash termux-setup.sh
echo "=== 1/4  Termux packages update ==="
yes | pkg update
yes | pkg upgrade
echo "=== 2/4  nodejs + python + ffmpeg ==="
pkg install -y nodejs-lts python ffmpeg || { echo "❌ pkg install fail - 'termux-change-repo' run කරලා වෙන mirror එකක් තෝරලා ආයෙත් try කරන්න"; exit 1; }
echo "=== 3/4  yt-dlp ==="
pip install -U yt-dlp || echo "⚠️ yt-dlp install fail - YouTube/FB commands විතරක් වැඩ නොකරයි"
echo "=== 4/4  bot packages (npm) ==="
cd "$(dirname "$0")"
npm install --legacy-peer-deps --no-audit --no-fund || { echo "❌ npm install fail - screenshot එකක් ගන්න"; exit 1; }
echo ""
echo "✅ Setup DONE!  දැන් bot එක start කරන්න:   npm start"
