/**
 * Downloader manager — YouTube / Facebook / media via yt-dlp.
 *
 * How it works (tested live from a datacenter IP):
 *   1. Auto-downloads two static binaries into ./bin on first use:
 *        - yt-dlp_linux   (github.com/yt-dlp/yt-dlp releases)
 *        - ffmpeg         (github.com/eugeneware/ffmpeg-static) for mp4 merging
 *   2. Downloads run through yt-dlp → temp file → Buffer → WhatsApp.
 *   3. OPTIONAL V2Ray proxy fallback:
 *        Set V2RAY_SUB_URL env (a subscription URL or a single vmess:// /
 *        vless:// link). If a direct download fails with an IP block
 *        (sign-in wall / 403 / nsig), the manager starts Xray (also
 *        auto-downloaded), connects through the first server, and rotates to
 *        the next server on every failure. When every server is exhausted it
 *        RE-FETCHES the subscription — so expired/free-list configs
 *        auto-update themselves.
 */

const { spawn, execFile } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const axios = require('axios');

const BIN = path.join(__dirname, 'bin');
let YTDLP = path.join(BIN, 'yt-dlp');
let FFMPEG = path.join(BIN, 'ffmpeg');
let XRAY = path.join(BIN, 'xray');

// Termux / ARM phones: the auto-downloaded binaries are linux-x64 only and will NOT run.
// There we use system binaries from PATH (pkg install ffmpeg / pip install yt-dlp).
const IS_TERMUX = !!(process.env.PREFIX && process.env.PREFIX.includes('com.termux')) || process.platform === 'android';
const CAN_AUTO_DOWNLOAD = process.platform === 'linux' && process.arch === 'x64' && !IS_TERMUX;
function which(cmd) {
    for (const d of (process.env.PATH || '').split(path.delimiter)) {
        if (!d) continue;
        const p = path.join(d, cmd);
        try { fs.accessSync(p, fs.constants.X_OK); if (fs.statSync(p).isFile()) return p; } catch { }
    }
    return null;
}
function useSystem() {
    if (!fs.existsSync(YTDLP)) { const p = which('yt-dlp'); if (p) YTDLP = p; }
    if (!fs.existsSync(FFMPEG)) { const p = which('ffmpeg'); if (p) FFMPEG = p; }
    if (!fs.existsSync(XRAY)) { const p = which('xray'); if (p) XRAY = p; }
}
useSystem();

const state = {
    binariesReady: false,
    xray: { child: null, port: 0, servers: [], idx: 0, enabled: false, activeServer: null, lastRefresh: 0, config: path.join(BIN, 'xray-config.json') },
    lastError: null
};

const log = (color, text) => console.log(`\x1b[${color}m\x1b[1m[Downloader]\x1b[0m ${text}`);

// ────────────────────────── binaries ──────────────────────────
async function downloadTo(url, dest) {
    const r = await axios.get(url, { responseType: 'stream', timeout: 120000 });
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    const w = fs.createWriteStream(dest);
    await new Promise((res, rej) => {
        r.data.pipe(w);
        w.on('finish', res);
        w.on('error', rej);
    });
    fs.chmodSync(dest, 0o755);
}

async function latestAssetUrl(repo, assetName) {
    const r = await axios.get(`https://api.github.com/repos/${repo}/releases/latest`, {
        headers: { 'User-Agent': 'PteroWA-Bot' }, timeout: 20000
    });
    const a = (r.data.assets || []).find(a => a.name === assetName);
    if (!a) throw new Error(`asset ${assetName} not found in ${repo}`);
    return a.browser_download_url;
}

async function ensureBinaries() {
    if (state.binariesReady) return;
    useSystem();
    if (!CAN_AUTO_DOWNLOAD) {
        const miss = [];
        if (!fs.existsSync(YTDLP)) miss.push('yt-dlp  →  pip install -U yt-dlp');
        if (!fs.existsSync(FFMPEG)) miss.push('ffmpeg  →  pkg install ffmpeg');
        if (miss.length) throw new Error('Termux/ARM: මේවා install කරලා bot එක restart කරන්න:\n' + miss.join('\n'));
        state.binariesReady = true;
        return;
    }
    if (!fs.existsSync(YTDLP)) {
        await downloadTo(await latestAssetUrl('yt-dlp/yt-dlp', 'yt-dlp_linux'), YTDLP);
        log('32', '📦 yt-dlp ready');
    }
    if (!fs.existsSync(FFMPEG)) {
        await downloadTo('https://github.com/eugeneware/ffmpeg-static/releases/latest/download/ffmpeg-linux-x64', FFMPEG);
        log('32', '📦 ffmpeg ready');
    }
    state.binariesReady = true;
}

// ────────────────────────── v2ray (optional) ──────────────────────────
function parseVmess(link) {
    try {
        const j = JSON.parse(Buffer.from(link.slice('vmess://'.length), 'base64').toString('utf8'));
        return {
            tag: j.ps || 'vmess', protocol: 'vmess',
            address: j.add, port: +j.port, id: j.id, aid: +(j.aid ?? j.alterId ?? 0),
            network: j.net || 'tcp', tls: j.tls === 'tls' ? 'tls' : undefined,
            host: j.host || undefined, path: j.path || undefined
        };
    } catch { return null; }
}

function parseVless(link) {
    try {
        const u = new URL(link);
        const q = u.searchParams;
        return {
            tag: decodeURIComponent(u.hash.slice(1)) || 'vless', protocol: 'vless',
            address: u.hostname, port: +u.port, id: u.username,
            network: q.get('type') || 'tcp', tls: q.get('security') || undefined,
            sni: q.get('sni') || undefined, host: q.get('host') || undefined,
            path: q.get('path') || undefined, pbk: q.get('pbk') || undefined,
            sid: q.get('sid') || undefined, fp: q.get('fp') || undefined,
            flow: q.get('flow') || undefined
        };
    } catch { return null; }
}

function buildOutbound(s) {
    const stream = { network: s.network };
    if (s.network === 'ws') stream.wsSettings = { path: s.path || '/', headers: s.host ? { Host: s.host } : undefined };
    else if (s.network === 'grpc') stream.grpcSettings = { serviceName: (s.path || '').replace(/^\/?/, '') };
    if (s.tls === 'tls' || s.tls === 'reality') {
        stream.security = s.tls;
        if (s.tls === 'tls') stream.tlsSettings = { serverName: s.host || s.sni || s.address, allowInsecure: true };
        else stream.realitySettings = {
            serverName: s.sni || s.host || s.address, publicKey: s.pbk,
            shortId: s.sid || '', spiderX: '/', fingerprint: s.fp || 'chrome'
        };
    }
    const settings = s.protocol === 'vmess'
        ? { vnext: [{ address: s.address, port: s.port, users: [{ id: s.id, alterId: s.aid, security: 'auto' }] }] }
        : { vnext: [{ address: s.address, port: s.port, users: [{ id: s.id, encryption: 'none', flow: s.flow || '' }] }] };
    return { tag: 'proxy', protocol: s.protocol, settings, streamSettings: stream };
}

async function refreshSubscription(force = false) {
    const X = state.xray;
    const now = Date.now();
    if (!force && now - X.lastRefresh < 5 * 60 * 1000) return; // cooldown
    X.lastRefresh = now;

    const subUrl = process.env.V2RAY_SUB_URL;
    if (!subUrl) return;

    let text = subUrl;
    if (!/vmess:\/\//.test(subUrl) && !/vless:\/\//.test(subUrl)) {
        const r = await axios.get(subUrl, { timeout: 30000, headers: { 'User-Agent': 'v2rayNG/1.8.0' } });
        text = String(r.data);
        if (!/vmess:\/\//.test(text) && !/vless:\/\//.test(text)) text = Buffer.from(text.trim(), 'base64').toString('utf8');
    }
    const servers = [
        ...(text.match(/vmess:\/\/\S+/g) || []).map(parseVmess),
        ...(text.match(/vless:\/\/\S+/g) || []).map(parseVless)
    ].filter(Boolean);
    if (servers.length) {
        X.servers = servers;
        X.idx = 0;
        X.enabled = true;
        log('36', `🌐 V2Ray: ${servers.length} servers loaded from subscription`);
    }
}

function stopXray() {
    const X = state.xray;
    if (X.child) { try { X.child.kill('SIGKILL'); } catch { } X.child = null; }
}

function startXray() {
    const X = state.xray;
    const s = X.servers[X.idx];
    if (!s) return false;
    stopXray();
    X.port = 20000 + Math.floor(Math.random() * 20000);
    const cfg = {
        log: { loglevel: 'error' },
        inbounds: [{ listen: '127.0.0.1', port: X.port, protocol: 'socks', settings: { udp: false } }],
        outbounds: [buildOutbound(s), { tag: 'direct', protocol: 'freedom' }]
    };
    fs.writeFileSync(X.config, JSON.stringify(cfg));
    try {
        X.child = spawn(XRAY, ['run', '-c', X.config], { stdio: 'ignore' });
        X.child.on('exit', () => { X.child = null; });
        X.activeServer = `${s.protocol}://${s.address}:${s.port}`;
        return true;
    } catch { return false; }
}

/** rotate to the next proxy server; refresh subscription when exhausted (auto-update) */
async function rotateProxy() {
    const X = state.xray;
    if (!X.enabled) return false;
    X.idx++;
    if (X.idx >= X.servers.length) {
        log('33', '🌐 V2Ray: all servers exhausted — re-fetching subscription (auto-update)...');
        await refreshSubscription(true);
        X.idx = 0;
        if (!X.servers.length) return false;
    }
    const ok = startXray();
    if (ok) log('33', `🌐 V2Ray: rotated → [${X.idx + 1}/${X.servers.length}] ${X.activeServer}`);
    return ok;
}

async function ensureXrayBinary() {
    useSystem();
    if (fs.existsSync(XRAY)) return true;
    if (!CAN_AUTO_DOWNLOAD) { log('33', 'xray: auto-download is x64-only — proxy disabled on this device'); return false; }
    try {
        const url = await latestAssetUrl('XTLS/Xray-core', 'Xray-linux-64.zip');
        const zipBuf = Buffer.from((await axios.get(url, { responseType: 'arraybuffer', timeout: 120000 })).data);
        fs.mkdirSync(BIN, { recursive: true });
        const zipPath = path.join(BIN, 'xray.zip');
        fs.writeFileSync(zipPath, zipBuf);
        await new Promise((res, rej) =>
            execFile('unzip', ['-o', '-j', zipPath, 'xray', '-d', BIN], e => e ? rej(e) : res()));
        fs.unlinkSync(zipPath);
        fs.chmodSync(XRAY, 0o755);
        log('32', '📦 xray ready');
        return true;
    } catch (e) { log('31', `xray download failed: ${e.message}`); return false; }
}

async function enableProxyIfNeeded() {
    const X = state.xray;
    if (X.child) return true;                                    // already running
    if (!X.servers.length) await refreshSubscription(true);      // first use
    if (!X.servers.length) return false;                         // no subscription
    if (!(await ensureXrayBinary())) return false;
    const ok = startXray();
    if (ok) log('36', `🌐 V2Ray active: ${X.activeServer} [1/${X.servers.length}]`);
    return ok;
}

// ────────────────────────── yt-dlp runner ──────────────────────────
function runYtdlp(args, timeoutMs = 300000) {
    return new Promise((resolve) => {
        const child = spawn(YTDLP, args, { stdio: ['ignore', 'pipe', 'pipe'] });
        let out = '', err = '', done = false;
        const finish = (code) => {
            if (done) return; done = true; clearTimeout(t);
            resolve({ code, out, err });
        };
        const t = setTimeout(() => { try { child.kill('SIGKILL'); } catch { } finish(-1); }, timeoutMs);
        child.stdout.on('data', d => { out += d; });
        child.stderr.on('data', d => { err += d; });
        child.on('exit', finish);
        child.on('error', (e) => { err += e.message; finish(-2); });
    });
}

function parseYtError(text) {
    const m = String(text).match(/ERROR:\s*\[?[\w-]*\]?\s*(.*)/);
    return (m ? m[1] : (text || 'unknown yt-dlp error')).split('\n')[0].slice(0, 200);
}

/** fetch metadata (title/duration/uploader/formats) without downloading */
async function info(url) {
    await ensureBinaries();
    const r = await runYtdlp(['-J', '--no-playlist', '--no-warnings', '--skip-download', url], 90000);
    if (r.code !== 0) throw new Error(parseYtError(r.err || r.out));
    return JSON.parse(r.out);
}

function tmpCleanup(tmpdir, prefix) {
    try {
        for (const f of fs.readdirSync(tmpdir)) {
            if (f.startsWith(prefix + '.') || f === prefix) {
                try { fs.unlinkSync(path.join(tmpdir, f)); } catch { }
            }
        }
    } catch { }
}

/**
 * Download media into a Buffer.
 * opts: { mode: 'audio'|'video', maxMB, videoHeights }
 * Strategy: direct → if IP-blocked and V2RAY_SUB_URL set → via proxy with
 * rotation; smaller quality fallback while size-capped.
 */
async function download(url, { mode = 'video', maxMB = 60, videoHeights = [720, 480, 360] } = {}) {
    await ensureBinaries();
    const tmpdir = os.tmpdir();
    const attempts = [];
    const heights = mode === 'video' ? videoHeights : [null];

    for (const viaProxy of [false, true]) {
        if (viaProxy && !(await enableProxyIfNeeded())) break;  // no subscription configured

        for (const h of heights) {
            const fmt = mode === 'audio'
                ? 'bestaudio[ext=m4a]/bestaudio'
                : `bv*[height<=${h}][ext=mp4]+ba[ext=m4a]/b[height<=${h}][ext=mp4]/b[height<=${h}]/b`;
            const prefix = `wa-dl-${process.pid}-${Date.now().toString(36)}`;
            const args = [
                '--no-playlist', '--no-warnings',
                '--ffmpeg-location', FFMPEG,
                '--max-filesize', `${maxMB}M`,
                '-f', fmt,
                '-o', path.join(tmpdir, prefix + '.%(ext)s'),
                url
            ];
            if (mode === 'video') args.push('--merge-output-format', 'mp4');
            if (viaProxy) args.push('--proxy', `socks5://127.0.0.1:${state.xray.port}`);

            attempts.push(`${viaProxy ? 'proxy' : 'direct'}${h ? '-' + h + 'p' : ''}`);
            const r = await runYtdlp(args);

            const produced = fs.readdirSync(tmpdir).find(f => f === prefix || f.startsWith(prefix + '.'));
            if (r.code === 0 && produced) {
                const finalPath = path.join(tmpdir, produced);
                const buffer = fs.readFileSync(finalPath);
                try { fs.unlinkSync(finalPath); } catch { }
                return { buffer, ext: path.extname(produced).slice(1) || 'mp4', via: viaProxy ? 'proxy' : 'direct', height: h };
            }
            tmpCleanup(tmpdir, prefix);

            const errText = String(r.err || r.out);
            state.lastError = parseYtError(errText);
            const ipBlocked = /sign in|bot|confirm|nsig|throttl|forbidden|403|429/i.test(errText);

            if (viaProxy) await rotateProxy();          // this server failed → next
            else if (ipBlocked) break;                  // direct IP blocked → try proxy
            // else: size/format issue → try next height
        }
    }
    throw new Error(state.lastError || 'download failed (' + attempts.join(', ') + ')');
}

function status() {
    return {
        binaries: {
            'yt-dlp': fs.existsSync(YTDLP),
            ffmpeg: fs.existsSync(FFMPEG),
            xray: fs.existsSync(XRAY)
        },
        proxy: state.xray.enabled
            ? { enabled: true, servers: state.xray.servers.length, active: state.xray.activeServer }
            : { enabled: false }
    };
}

function shutdown() { stopXray(); }

module.exports = { info, download, status, shutdown, ensureBinaries, _paths: () => ({ YTDLP, FFMPEG, XRAY, IS_TERMUX, CAN_AUTO_DOWNLOAD }) };
