Arena AI v2.0 — ඔයාට විතරක් වැඩ කරන WhatsApp bot එක (AI + Downloader)
=====================================================================
Commands ("Message yourself" chat එකේ ගහන්න):
  .ai <ප්‍රශ්නය>             AI එකෙන් අහන්න (සිංහල OK). කලින් කතාව මතක තියාගන්නවා (පණිවිඩ 10ක්)
  (message එකකට reply කරලා) .ai   → ඒ message එක ගැන පැහැදිලි කරනවා / translate කරනවා
  .ai reset                  කතාව අලුතෙන් පටන් ගන්න
  .download <link>           file එක download කරලා document එකක් විදියට එවනවා (.dl / .dn)
  .setkey gemini <KEY>       Gemini free key දාන්න   (key message එක auto මැකෙනවා)
  .setkey groq <KEY>         Groq free key දාන්න
  .keys                      keys තියෙනවද බලන්න      .delkey gemini|groq  → key මකන්න
  .ping / .help

AI ගැන ඇත්ත: උත්තර දෙන්නේ Google Gemini / Groq free models (Arena.ai agent එක නෙවෙයි).
Gemini fail වුණොත් Groq එකට auto මාරු වෙනවා. Free limits ඉවර වුණොත් ටිකකින් ආයෙත් try කරන්න.

Free keys:
  Gemini → https://aistudio.google.com/apikey   (Google account → Create API key)
  Groq   → https://console.groq.com/keys        (login → Create API Key)

Download support: direct links, GitHub, Google Drive (public), MediaFire, MEGA, Dropbox, Pixeldrain,
litterbox/catbox, x0.at, transfer.archivete.am, filebin. (gofile / LimeWire / folders support නෑ). Max 2 GB.

🔒 Private: ඔයා යවන messages විතරයි. වෙන අය commands යැව්වත් ignore.

Termux setup:
  pkg install -y curl unzip
  cd ~ && curl -L -o Arena-AI.zip https://raw.githubusercontent.com/matheeshasanjana83-alt/abc/main/downloads/Arena-AI.zip && unzip -o Arena-AI.zip
  cd ~/Arena-AI && bash termux-setup.sh
  termux-wake-lock
  npm start
ආයෙත් start:  cd ~/Arena-AI && termux-wake-lock && npm start
Re-pair:       cd ~/Arena-AI && rm -rf auth && npm start
Test:          npm test
