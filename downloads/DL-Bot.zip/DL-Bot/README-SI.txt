DL-Bot v1.0 — ඔයාට විතරක් වැඩ කරන WhatsApp download bot එක
=============================================================
Command:
  .download <link>          file එක download කරලා document එකක් විදියට එවනවා
  .download <link1> <link2> links කිහිපයක් (උපරිම 10)
  .dl / .dn                 .download එකමයි (කෙටි නම්)
  .ping                     bot එක වැඩද බලන්න
  .help                     උදව්

Support කරන links: ඕනෑම direct link, GitHub (blob/raw/releases), Google Drive (public file),
MediaFire, MEGA (file/folder), Dropbox, Pixeldrain, litterbox/catbox, x0.at,
transfer.archivete.am, filebin ...
Support නැති: gofile, LimeWire (bots block කරනවා / encrypt කරලා), Drive/MediaFire folders.
Max size: 2 GB (WhatsApp limit). වෙනස් කරන්න: DL_MAX_MB=500 npm start

🔒 Private: ඔයා (link කරපු number එක) යවන messages විතරයි. වෙන අය .download යැව්වත් ignore.

Termux setup:
  pkg install -y curl unzip
  cd ~ && curl -L -o DL-Bot.zip https://raw.githubusercontent.com/matheeshasanjana83-alt/abc/main/downloads/DL-Bot.zip && unzip -o DL-Bot.zip
  cd ~/DL-Bot && bash termux-setup.sh
  termux-wake-lock
  npm start          (number එක අහනකොට 94771234567 වගේ දාන්න → pairing code එක WhatsApp එකේ ගහන්න)

ආයෙත් start කරන්න:  cd ~/DL-Bot && termux-wake-lock && npm start
Re-pair කරන්න:       cd ~/DL-Bot && rm -rf auth && npm start
Test (account නැතුව): npm test
