// npm test  → simulated WhatsApp messages (no real account needed)
const fs = require('fs');
const { onMessages, getText } = require('./bot');
let n = 0, ok = 0, bad = 0;
const t = (name, cond) => { cond ? ok++ : bad++; console.log(`  ${cond ? '✅' : '❌'} ${name}`); };
const ME = '94771234567@s.whatsapp.net';
const mk = (text, fromMe = true, jid = ME) => ({ key: { id: 'IN' + (++n), remoteJid: jid, fromMe }, message: { conversation: text } });
(async () => {
    const out = [];
    const send = async (jid, c) => { const e = { jid, ...c }; if (c.document) { e.size = fs.statSync(c.document.url).size; e.exists = true; } out.push(e); return { key: { id: 'OUT' + (++n) } }; };
    const run = async (msg) => { out.length = 0; await onMessages({ type: 'notify', messages: [msg] }, send); return out; };

    let r = await run(mk('.ping')); t('.ping → Pong', r.length === 1 && /Pong/.test(r[0].text));
    r = await run(mk('.ping', false, '94770000000@s.whatsapp.net')); t('🔒 වෙන කෙනෙක් .ping → ignore', r.length === 0);
    r = await run(mk('.download https://x0.at/D07z.zip', false, '120363@g.us')); t('🔒 group එකේ වෙන කෙනෙක් .download → ignore', r.length === 0);
    r = await run(mk('hello')); t('සාමාන්‍ය message → ignore', r.length === 0);
    r = await run(mk('.download')); t('.download link නැතුව → help', r.length === 1 && /DL-Bot/.test(r[0].text));
    r = await run(mk('.download https://raw.githubusercontent.com/matheeshasanjana83-alt/abc/main/downloads/Joystick-Layout-NoCLEO-v1.zip'));
    const doc = r.find(x => x.document);
    t('.download GitHub → document එවනවා', !!doc && doc.fileName === 'Joystick-Layout-NoCLEO-v1.zip' && doc.size === 3127);
    t('progress/status edit message', r.some(x => x.edit && /ඉවරයි/.test(x.text)));
    t('temp file එක delete වෙනවා', await new Promise(res => setTimeout(() => res(!fs.existsSync(doc.document.url)), 300)));
    r = await run(mk('.dl https://raw.githubusercontent.com/matheeshasanjana83-alt/abc/main/downloads/Joystick-Layout-NoCLEO-v1.zip https://github.com/matheeshasanjana83-alt/abc/blob/main/downloads/SmokeBoy.zip'));
    t('.dl links 2ක් → documents 2ක්', r.filter(x => x.document).length === 2);
    r = await run(mk('.download https://www.google.com/')); t('web page link → පැහැදිලි error', r.some(x => x.edit && /web page/.test(x.text)) && !r.some(x => x.document));
    t('getText: extendedTextMessage', getText({ extendedTextMessage: { text: ' .ping ' } }) === '.ping');
    t('getText: ephemeral wrapper', getText({ ephemeralMessage: { message: { conversation: '.dl x' } } }) === '.dl x');
    console.log(bad ? `\n⚠️ ${ok} passed, ${bad} failed` : `\n🎉 ALL ${ok} TESTS PASSED`);
    process.exit(bad ? 1 : 0);
})();
