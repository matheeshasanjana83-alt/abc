/**
 * DL-Bot — private WhatsApp bot with ONE powerful command:  .download <link> [link2 ...]
 * Works only for YOU (messages you send). Others are ignored silently.
 */
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const pino = require('pino');
const baileys = require('@whiskeysockets/baileys');
const makeWASocket = baileys.default;
const { useMultiFileAuthState, DisconnectReason, Browsers, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = baileys;
const { download, human, MAX_BYTES } = require('./downloader');

const AUTH = path.join(__dirname, 'auth');
const sentIds = new Set();
const log = (t) => console.log(`[${new Date().toLocaleTimeString('en-GB')}] ${t}`);
let pairingAsked = false;

function ask(q) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((r) => rl.question(q, (a) => { rl.close(); r(a); }));
}

function getText(m) {
    let x = m;
    for (let i = 0; i < 5 && x; i++) {
        const inner = x.ephemeralMessage?.message || x.viewOnceMessage?.message || x.viewOnceMessageV2?.message || x.documentWithCaptionMessage?.message || x.editedMessage?.message;
        if (!inner) break;
        x = inner;
    }
    return (x?.conversation || x?.extendedTextMessage?.text || x?.imageMessage?.caption || x?.documentMessage?.caption || '').trim();
}

const HELP = `⬇️ *DL-Bot*

*.download <link>*  — file එක download කරලා එවනවා
  (links කිහිපයක් එකට: .download link1 link2)
*.ping*  — bot එක වැඩද බලන්න

✅ Support: direct links, GitHub, Google Drive, MediaFire, MEGA, Dropbox, Pixeldrain, litterbox/catbox, x0.at, transfer.archivete.am, filebin...
📏 Max: ${human(MAX_BYTES)} per file`;

async function start() {
    fs.mkdirSync(AUTH, { recursive: true });
    const { state, saveCreds } = await useMultiFileAuthState(AUTH);
    let version;
    try { version = (await fetchLatestBaileysVersion()).version; } catch { version = [2, 3000, 1043857760]; }
    const logger = pino({ level: 'silent' });

    const sock = makeWASocket({
        version, logger,
        browser: Browsers.macOS('Chrome'),
        auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) },
        markOnlineOnConnect: false,
        syncFullHistory: false,
        shouldSyncHistoryMessage: () => false,
        getMessage: async () => undefined,
    });
    sock.ev.on('creds.update', saveCreds);

    const send = async (jid, content, opts) => {
        const s = await sock.sendMessage(jid, content, opts);
        if (s?.key?.id) { sentIds.add(s.key.id); if (sentIds.size > 500) sentIds.delete(sentIds.values().next().value); }
        return s;
    };

    sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
        if (qr && !sock.authState.creds.registered && !pairingAsked) {
            pairingAsked = true;
            let num = String(process.env.WA_PHONE_NUMBER || '').replace(/\D/g, '');
            if (!num) num = String(await ask('📱 ඔයාගේ WhatsApp number එක (උදා 94771234567): ')).replace(/\D/g, '');
            if (num.startsWith('0')) num = '94' + num.slice(1);
            try {
                let code;
                for (let i = 0; i < 3 && !code; i++) {
                    try { code = await sock.requestPairingCode(num); }
                    catch (e) { if (i === 2) throw e; await new Promise(r => setTimeout(r, 3000)); }
                }
                code = code.match(/.{1,4}/g).join('-');
                console.log('\n════════════════════════════════════');
                console.log(`   🔢 PAIRING CODE:  ${code}`);
                console.log('════════════════════════════════════');
                console.log('WhatsApp → Linked devices → Link a device →');
                console.log('"Link with phone number instead" → මේ code එක ගහන්න\n');
            } catch (e) { log('❌ Pairing code fail: ' + e.message); pairingAsked = false; }
        }
        if (connection === 'open') {
            log('✅ WhatsApp Connected! "Message yourself" chat එකේ .ping ගහලා බලන්න');
            try { await send(sock.user.id.split(':')[0] + '@s.whatsapp.net', { text: '✅ *DL-Bot online!*\n\n' + HELP }); } catch { }
        }
        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            if (code === DisconnectReason.loggedOut) {
                log('❌ Logged out (device එක unlink කළා). Session එක මකලා නවත්තනවා — ආයෙත් npm start කරලා pair කරන්න.');
                fs.rmSync(AUTH, { recursive: true, force: true });
                process.exit(0);
            }
            log(`⚠️ Connection වැහුණා (${code ?? '?'}) — තත්පර 3 කින් ආයෙත් connect වෙනවා...`);
            pairingAsked = code === 515 ? pairingAsked : false;
            setTimeout(() => start().catch(e => log('start error: ' + e.message)), 3000);
        }
    });

    sock.ev.on('messages.upsert', (u) => onMessages(u, send));
}

async function onMessages({ messages, type }, send) {
        if (type !== 'notify') return;
        for (const msg of messages) {
            try {
                if (!msg.message || !msg.key.fromMe) continue;          // 🔒 PRIVATE: only messages YOU send
                if (sentIds.has(msg.key.id)) continue;                 // never react to our own replies
                const text = getText(msg.message);
                if (!text.startsWith('.')) continue;
                const jid = msg.key.remoteJid;
                const [cmd, ...rest] = text.split(/\s+/);
                const c = cmd.toLowerCase();

                if (c === '.ping') { await send(jid, { text: '🏓 Pong! DL-Bot වැඩ ✅' }, { quoted: msg }); continue; }
                if (c === '.help' || c === '.menu') { await send(jid, { text: HELP }, { quoted: msg }); continue; }
                if (!['.download', '.dl', '.dn'].includes(c)) continue;

                const links = (text.match(/https?:\/\/\S+/g) || []).slice(0, 10);
                if (!links.length) { await send(jid, { text: HELP }, { quoted: msg }); continue; }
                for (const link of links) await handleDownload(send, jid, msg, link);
            } catch (e) { log('handler error: ' + e.message); }
        }
}

async function handleDownload(send, jid, msg, link) {
    const status = await send(jid, { text: `⏳ Download වෙනවා...\n${link}` }, { quoted: msg });
    let last = 0;
    const edit = async (t) => { try { await send(jid, { text: t, edit: status.key }); } catch { } };
    const onProgress = (loaded, total, speed) => {
        const now = Date.now();
        if (now - last < 4000) return;
        last = now;
        const pct = total ? Math.floor(loaded * 100 / total) : null;
        const bar = pct === null ? '' : '▰'.repeat(Math.round(pct / 10)) + '▱'.repeat(10 - Math.round(pct / 10)) + ` ${pct}%\n`;
        edit(`⬇️ Downloading...\n${bar}${human(loaded)} / ${human(total)}  •  ${human(speed)}/s`);
    };
    let files = [];
    try {
        files = await download(link, onProgress);
        for (const f of files) {
            await edit(`📤 WhatsApp එකට යවනවා... (${f.name}, ${human(f.size)})`);
            await send(jid, { document: { url: f.path }, fileName: f.name, mimetype: f.mime, caption: `✅ ${f.name}\n📦 ${human(f.size)}` }, { quoted: msg });
        }
        await edit(`✅ ඉවරයි — file ${files.length} ක් එව්වා`);
        log(`✅ ${link} → ${files.map(f => f.name + ' ' + human(f.size)).join(', ')}`);
    } catch (e) {
        await edit(`❌ Download fail වුණා\n${link}\n\n${String(e.message).slice(0, 300)}`);
        log(`❌ ${link}: ${e.message}`);
    } finally {
        for (const f of files) fs.rm(f.path, { force: true }, () => { });
    }
}

process.on('unhandledRejection', (e) => log('unhandled: ' + (e?.message || e)));
process.on('uncaughtException', (e) => log('uncaught: ' + e.message));
module.exports = { handleDownload, getText, onMessages };
if (require.main === module) {
    console.log('🚀 DL-Bot starting...');
    start().catch((e) => { log('Startup fail: ' + e.message); process.exit(1); });
}
