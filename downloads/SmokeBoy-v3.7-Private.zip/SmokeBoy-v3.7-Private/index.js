/**
 * Project DL SmokeBoy v3 — Baileys (WhatsApp Web multi-device protocol)
 *
 * Fixes over v2 (why v2 never replied to commands):
 *  1. v2 skipped every message with `fromMe === true`. Commands sent to your
 *     own number ("Message Yourself") ALWAYS arrive as fromMe=true, so the
 *     handler never saw them -> no replies. v3 processes fromMe messages and
 *     only skips messages this bot itself sent (tracked by message id).
 *  2. v2 `getMessage()` returned an empty proto message, breaking retries.
 *     v3 keeps a small cache of recent messages for correct retries.
 *  3. v3 unwraps viewOnce/ephemeral/document message wrappers when reading text.
 *  4. v3 pairing: number from env var or prompt, normalization, 428 retry,
 *     no double-prompt on QR refresh, survives reconnects.
 *  5. v3 reconnects on every non-logout disconnect and exits cleanly on
 *     logout (Pterodactyl auto-restarts -> re-pair).
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const makeWASocket = require('@whiskeysockets/baileys').default;
const {
    useMultiFileAuthState,
    DisconnectReason,
    Browsers,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    jidNormalizedUser
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');

const config = require('./config');
const messageHandler = require('./handler');
const downloader = require('./downloader');
const { version } = require('./package.json');

// ─────────────────────────────── logging ───────────────────────────────
const c = {
    reset: '\x1b[0m', bright: '\x1b[1m',
    red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m',
    blue: '\x1b[34m', cyan: '\x1b[36m'
};
const ts = () => new Date().toLocaleTimeString('en-GB');
const log = (color, text) => console.log(`${c[color]}${c.bright}[${ts()} Ptero-WA]${c.reset} ${text}`);

// ─────────────────────────────── state ─────────────────────────────────
let sock = null;
let isConnected = false;
let pairingRequested = false;   // only one pairing request per connection attempt
let announced = false;          // send "bot online" notice once per process
const sentIds = new Set();      // ids of messages this bot sent (loop guard)
const messageCache = new Map(); // recent messages, used by getMessage retries
const MAX_CACHE = 100;

function rememberMessage(msg) {
    if (!msg?.key?.id) return;
    messageCache.set(msg.key.id, msg);
    if (messageCache.size > MAX_CACHE) {
        const firstKey = messageCache.keys().next().value;
        messageCache.delete(firstKey);
    }
}

// Safely send a message and remember its id so we never react to our own reply
async function send(jid, content, opts) {
    const sent = await sock.sendMessage(jid, content, opts);
    if (sent?.key?.id) {
        sentIds.add(sent.key.id);
        if (sentIds.size > 300) {
            const it = sentIds.values().next().value;
            sentIds.delete(it);
        }
        rememberMessage(sent);
    }
    return sent;
}

// ─────────────────────── terminal input (pairing) ──────────────────────
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((resolve) => rl.question(q, resolve));

function normalizePhone(raw) {
    let p = String(raw || '').replace(/\D/g, ''); // keep digits only
    if (p.startsWith('00')) p = p.slice(2);
    return p;
}

async function getPhoneNumber() {
    if (config.phoneNumber) return normalizePhone(config.phoneNumber);
    const raw = await ask(`${c.cyan}📱 Phone number (e.g. 94771234567): ${c.reset}`);
    return normalizePhone(raw);
}

// ───────────────────── HTTP status server (Pterodactyl) ────────────────
const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
        status: isConnected ? 'connected' : 'disconnected',
        bot: config.botName,
        user: sock?.user?.name || null,
        number: sock?.user?.id?.split(':')[0] || null,
        uptime: Math.floor(process.uptime())
    }, null, 2));
});

// ─────────────────────────── Baileys socket ────────────────────────────
async function connectToWhatsApp() {
    const sessionPath = path.join(__dirname, config.sessionName);
    if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);

    let version;
    try {
        const fetched = await fetchLatestBaileysVersion();
        version = fetched.version;
        log('blue', `WA Web version: ${version.join('.')} (latest: ${fetched.isLatest})`);
    } catch {
        // If web.whatsapp.com/sw.js is unreachable, use a known-good revision
        version = [2, 3000, 1043857760];
        log('yellow', `Could not fetch WA version, using fallback ${version.join('.')}`);
    }

    const logger = pino({ level: 'silent' });
    const msgRetryCounterCache = new Map();

    sock = makeWASocket({
        version,
        logger,
        browser: Browsers.macOS('Chrome'),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, logger)
        },
        msgRetryCounterCache,
        // Real stored messages for retry/decrypt failures (v2 returned {} here)
        getMessage: async (key) => messageCache.get(key?.id)?.message || undefined,
        syncFullHistory: false,
        // false => phone stays "primary", avoids presence conflicts & keeps
        // phone notifications working while the bot is linked
        markOnlineOnConnect: false,
        shouldSyncHistoryMessage: () => false,
        shouldIgnoreJid: (jid) => jid === 'status@broadcast' || jid?.endsWith('@newsletter')
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr, receivedPendingNotifications } = update;

        // ── Pairing code flow (fires once per connect while not registered) ──
        if (qr && !sock.authState.creds.registered && !pairingRequested) {
            pairingRequested = true;
            log('cyan', '╔══════════════════════════════════════════╗');
            log('cyan', '║      🔐 PAIRING CODE AUTHENTICATION      ║');
            log('cyan', '╚══════════════════════════════════════════╝');

            const phoneNumber = await getPhoneNumber();
            if (!phoneNumber || phoneNumber.length < 8 || phoneNumber.length > 15) {
                log('red', `❌ Invalid number "${phoneNumber}". Restart the server and try again.`);
                process.exit(1);
            }

            try {
                let code = null;
                // 428 = "precondition" — the socket was not fully ready; retry once
                for (let attempt = 1; attempt <= 2; attempt++) {
                    try {
                        log('yellow', `⏳ Requesting pairing code (attempt ${attempt})...`);
                        code = await sock.requestPairingCode(phoneNumber);
                        break;
                    } catch (err) {
                        if (attempt === 2) throw err;
                        const sc = err?.output?.statusCode;
                        if (sc !== 428) throw err;
                        log('yellow', '⚠️ Socket not ready (428), retrying in 3s...');
                        await new Promise(r => setTimeout(r, 3000));
                    }
                }

                log('green', '╔══════════════════════════════════════════╗');
                log('green', `║  🔢 YOUR PAIRING CODE: ${c.bright}${code}         ║`);
                log('green', '╚══════════════════════════════════════════╝');
                log('cyan', '📲 1. Open WhatsApp on your phone');
                log('cyan', '📲 2. Settings → Linked Devices → Link a Device');
                log('cyan', '📲 3. Tap "Link with phone number instead"');
                log('cyan', `📲 4. Enter the 8-digit code above`);
                log('yellow', '⏳ Waiting for you to enter the code (keep this console open)...');
            } catch (err) {
                log('red', `❌ Pairing failed: ${err.message}`);
                pairingRequested = false; // allow retry after reconnect
            }
        }

        if (connection === 'connecting') {
            log('yellow', '🔄 Connecting to WhatsApp...');
        } else if (connection === 'open') {
            isConnected = true;
            const cleanJid = sock.user?.id?.split(':')[0] || 'unknown';
            config.owner = jidNormalizedUser(sock.user?.id) || (cleanJid + '@s.whatsapp.net');

            log('green', '✅ WhatsApp Connected!');
            log('green', `🤖 Bot: ${config.botName}`);
            log('green', `📱 Number: ${cleanJid}`);
            log('blue', `💡 Open WhatsApp → your own chat ("Message Yourself") → send ${config.prefix}menu`);

            if (!announced) {
                announced = true;
                try {
                    await send(config.owner, {
                        text: `✅ *${config.botName}* is online!\n\nSend *${config.prefix}menu* to see commands.\n\n_${config.prefix}ping • ${config.prefix}info • ${config.prefix}owner_`
                    });
                } catch { /* non-fatal */ }
            }
        } else if (connection === 'close') {
            isConnected = false;
            const statusCode = (lastDisconnect?.error instanceof Boom)
                ? lastDisconnect.error.output?.statusCode
                : undefined;

            if (statusCode === DisconnectReason.loggedOut) {
                log('red', '❌ Logged out (device unlinked from phone). Clearing session...');
                fs.rmSync(sessionPath, { recursive: true, force: true });
                log('cyan', '🔄 Session deleted. Restarting to pair again...');
                process.exit(0); // Pterodactyl auto-restarts the process
            }

            if (statusCode === DisconnectReason.connectionReplaced) {
                log('red', '❌ Connection replaced — another session logged in with the same');
                log('red', '   QR/pairing code. Close other sessions (Linked Devices) or delete');
                log('red', '   the auth_info_baileys folder and re-pair. Exiting...');
                process.exit(0);
            }

            log('yellow', `⚠️ Connection closed (code ${statusCode ?? '?'}). Reconnecting in 3s...`);
            setTimeout(connectToWhatsApp, 3000);
        }

        if (receivedPendingNotifications) {
            log('cyan', '📬 Received pending notifications (history sync in progress)...');
        }
    });

    // ── Incoming messages — THE v2 BUG FIX ──
    // v2: `if (msg.key.fromMe) continue;` killed every self-chat command.
    // v3: process fromMe messages (self-chat = "Message Yourself"), but skip
    //     messages this bot itself sent (sentIds) so it never replies to itself.
    sock.ev.on('messages.upsert', async (m) => {
        if (m.type !== 'notify') return; // 'append' = history sync, not new messages

        for (const msg of m.messages) {
            if (!msg?.message) continue;                 // reactions/protocol msgs
            rememberMessage(msg);
            if (sentIds.has(msg.key.id)) continue;       // our own outgoing reply

            try {
                await messageHandler(sock, msg, config, send);
            } catch (err) {
                log('red', `Handler error: ${err.message}`);
            }
        }
    });
}

// ────────────────────────── graceful shutdown ──────────────────────────
function shutdown(sig) {
    log('yellow', `\n👋 ${sig} — shutting down...`);
    try { sock?.end(undefined); } catch { /* ignore */ }
    try { downloader.shutdown(); } catch { /* ignore */ }
    rl.close();
    server.close();
    process.exit(0);
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', (reason) => log('red', `Unhandled rejection: ${reason}`));
process.on('uncaughtException', (err) => {
    log('red', `Uncaught exception: ${err.message}`);
    // keep running if possible — Baileys sockets can recover via reconnect
});

// ──────────────────────────────── start ────────────────────────────────
server.listen(config.port, '0.0.0.0', () => {
    const nCommands = (messageHandler.getCommands?.() || []).length;
    const dlStatus = downloader.status();
    log('green', `🌐 Status server listening on 0.0.0.0:${config.port}`);
    log('cyan', `🚀 Project DL SmokeBoy v${version} starting...`);
    log('cyan', `📦 ${nCommands} commands loaded${nCommands < 10 ? ' (⚠️ some command files failed to load — check npm install)' : ''}`);
    log('cyan', `🧰 Downloader: yt-dlp ${dlStatus.binaries['yt-dlp'] ? '✅' : '(auto-downloads on first use)'}, ffmpeg ${dlStatus.binaries.ffmpeg ? '✅' : '(auto)'}`);
    if (process.env.V2RAY_SUB_URL) log('cyan', '🌐 V2Ray subscription configured (auto-rotate on IP block)');
    log('cyan', '🔧 Protocol: WhatsApp Web multi-device (Baileys, no browser)');
    connectToWhatsApp().catch((err) => {
        log('red', `Startup failed: ${err.message}`);
        process.exit(1);
    });
});
