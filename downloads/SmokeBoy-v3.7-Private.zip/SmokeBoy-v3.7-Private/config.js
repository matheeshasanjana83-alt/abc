const fs = require('fs');
const path = require('path');

// persisted user settings (prefix etc.) survive restarts
const settingsFile = path.join(__dirname, 'botsettings.json');
let persisted = {};
try {
    if (fs.existsSync(settingsFile)) persisted = JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
} catch { /* corrupt file — ignore */ }

module.exports = {
    botName: process.env.BOT_NAME || 'Project DL SmokeBoy',
    prefix: persisted.prefix || process.env.BOT_PREFIX || '.',
    // Auto-filled with the paired number on connect (your own number)
    owner: '',
    sessionName: 'auth_info_baileys',
    // If true, ONLY the owner (paired number) can use commands anywhere.
    // In "Message Yourself" chat you are always the owner.
    ownerOnly: !/^(1|true|yes)$/i.test(process.env.PUBLIC_MODE || ''),  // PRIVATE by default (only you). PUBLIC_MODE=true to open
    // Allow command usage inside groups (from any participant when ownerOnly=false)
    allowGroups: true,
    // Bind HTTP status server (Pterodactyl needs the port bound so the
    // server shows as running; SERVER_PORT is set automatically by the panel)
    port: process.env.SERVER_PORT || process.env.PORT || 3000,
    // WhatsApp number for pairing: set as env var to skip the terminal prompt
    // e.g. 94771234567 (country code + number, no + and no spaces)
    phoneNumber: process.env.WA_PHONE_NUMBER || ''
};
