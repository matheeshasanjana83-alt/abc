const os = require('os');
const { version } = require('../package.json');

module.exports = {
    name: 'info',
    aliases: ['status', 'botinfo', 'uptime', 'version'],
    category: 'settings',
    emoji: '📊',
    description: 'Bot system info + version',
    execute: async ({ reply, config }) => {
        const uptime = process.uptime();
        const h = Math.floor(uptime / 3600);
        const m = Math.floor((uptime % 3600) / 60);
        const s = Math.floor(uptime % 60);

        const text = `╭──「 📊 BOT INFO 」──╮
│
│  🤖 Name: ${config.botName}
│  🔖 Version: v${version}
│  📱 Number: ${config.owner.split('@')[0]}
│  🔰 Prefix: ${config.prefix}
│  🔧 Node.js: ${process.version}
│  💻 Platform: ${os.platform()} ${os.arch()}
│  ⏱️ Uptime: ${h}h ${m}m ${s}s
│  🧠 Memory: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB
│
╰────────────────╯

⚡ _WhatsApp Web Protocol (Baileys)_`;
        await reply({ text });
    }
};
