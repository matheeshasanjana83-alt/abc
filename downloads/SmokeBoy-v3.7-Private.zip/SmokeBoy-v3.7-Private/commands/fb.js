const dl = require('../downloader');

module.exports = {
    name: 'fb',
    aliases: ['facebook', 'fbdl', 'fbvideo'],
    category: 'download',
    emoji: '📘',
    description: 'Facebook video download (.fb <url>)',
    execute: async ({ send, msg, jid, args, reply }) => {
        const url = (args[0] || '').trim();
        if (!/facebook\.com|fb\.watch/i.test(url)) {
            return reply({
                text: `╭──「 📘 FACEBOOK DL 」──╮
│
│  Usage: \`.fb <video url>\`
│  Works with facebook.com/watch,
│  /videos/... and fb.watch links
│
│  📹 HD when available
│  📏 Max 80 MB
│
╰──────────────────╯`
            });
        }

        await reply({ text: '⏳ Fetching Facebook video...' });
        let meta;
        try {
            meta = await dl.info(url);
        } catch (e) {
            return reply({ text: `❌ ${e.message}\n\n💡 The video must be **public** — private/login videos can't be downloaded.` });
        }

        const title = (meta.title || 'Facebook video').slice(0, 150);
        await reply({ text: `⬇️ Downloading *${title}* ...` });

        try {
            const { buffer, via } = await dl.download(url, { mode: 'video', maxMB: 80 });
            await send(jid, {
                video: buffer,
                mimetype: 'video/mp4',
                caption: `📘 *${title}*${via === 'proxy' ? '\n🌐 via proxy' : ''}`
            }, { quoted: msg });
        } catch (e) {
            return reply({ text: `❌ Download failed: ${e.message}` });
        }
    }
};
