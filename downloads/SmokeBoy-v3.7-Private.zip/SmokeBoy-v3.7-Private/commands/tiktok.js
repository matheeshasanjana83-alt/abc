const axios = require('axios');

const MAX_VIDEO_BYTES = 60 * 1024 * 1024; // WhatsApp-friendly cap

function absoluteUrl(u) {
    if (!u) return null;
    return u.startsWith('/') ? 'https://tikwm.com' + u : u;
}

module.exports = {
    name: 'tiktok',
    aliases: ['tt', 'tik'],
    category: 'download',
    emoji: '🎵',
    description: 'TikTok video download (.tiktok <url>)',
    execute: async ({ send, msg, jid, args, reply }) => {
        const url = (args[0] || '').trim();
        if (!/(tiktok\.com|vt\.tiktok|vm\.tiktok)/i.test(url)) {
            return reply({
                text: `╭──「 🎵 TIKTOK DOWNLOADER 」──╮
│
│  Usage: \`.tiktok <video url>\`
│
│  🎬 No watermark
│  📏 Max ~60 MB
│  🔗 Any tiktok.com/share link
│
╰────────────────────╯`
            });
        }

        await reply({ text: '⏳ Fetching video (no watermark)...' });

        const api = await axios.get('https://tikwm.com/api/', {
            params: { url },
            timeout: 25000,
            headers: { 'User-Agent': 'Mozilla/5.0 PteroWA-Bot' }
        });

        if (api.data?.code !== 0) {
            return reply({ text: `❌ TikTok API error: ${api.data?.msg || 'unknown'}\n\nCheck the link is a valid video URL.` });
        }

        const d = api.data.data;
        const playUrl = absoluteUrl(d.hdplay || d.play);
        const musicUrl = absoluteUrl(d.music);

        const kb = (n) => n ? (n / 1024 / 1024).toFixed(1) + ' MB' : '—';
        const caption = `🎵 *${(d.title || 'TikTok video').slice(0, 200)}*

👤 @${d.author?.unique_id || 'unknown'} (${d.author?.nickname || ''})
⏱️ ${d.duration || '?'}s  |  📦 ${kb(d.size)}
❤️ ${d.digg_count ?? '—'}  |  💬 ${d.comment_count ?? '—'}  |  🔁 ${d.share_count ?? '—'}

✅ _No watermark — via DL SmokeBoy_`;

        try {
            const vid = await axios.get(playUrl, {
                responseType: 'arraybuffer',
                timeout: 90000,
                maxContentLength: MAX_VIDEO_BYTES,
                headers: { 'User-Agent': 'Mozilla/5.0 PteroWA-Bot' }
            });
            await send(jid, { video: Buffer.from(vid.data), caption, mimetype: 'video/mp4' }, { quoted: msg });
        } catch (err) {
            const why = /maxContentLength|larger than/i.test(String(err.message))
                ? 'video is bigger than 60 MB' : 'could not download the video file';
            return reply({ text: `❌ ${why}.\n${caption}` });
        }

        // bonus: send the sound as audio if small enough
        try {
            if (musicUrl) {
                const aud = await axios.get(musicUrl, {
                    responseType: 'arraybuffer',
                    timeout: 60000,
                    maxContentLength: 15 * 1024 * 1024
                });
                await send(jid, { audio: Buffer.from(aud.data), mimetype: 'audio/mpeg' }, { quoted: msg });
            }
        } catch { /* sound is a bonus — ignore failures */ }
    }
};
