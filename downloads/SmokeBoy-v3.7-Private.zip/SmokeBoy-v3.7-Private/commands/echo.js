module.exports = {
    name: 'echo',
    category: 'tools',
    emoji: '💬',
    aliases: ['say'],
    description: 'Repeat your text',
    ownerOnly: false,
    execute: async ({ reply, args }) => {
        if (!args.length) return reply({ text: '❓ Usage: .echo hello world' });
        await reply({ text: args.join(' ') });
    }
};
