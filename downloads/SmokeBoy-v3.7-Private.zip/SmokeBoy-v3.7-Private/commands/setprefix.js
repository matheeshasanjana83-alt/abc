const fs = require('fs');
const path = require('path');

const settingsFile = path.join(__dirname, '..', 'botsettings.json');

function saveSettings(data) {
    fs.writeFileSync(settingsFile, JSON.stringify(data, null, 2));
}

module.exports = {
    name: 'setprefix',
    aliases: ['prefix'],
    category: 'settings',
    emoji: '🔰',
    description: 'Change command prefix (.setprefix !)',
    ownerOnly: true,
    execute: async ({ reply, config, args }) => {
        const p = (args[0] || '').trim();

        if (!p) {
            return reply({ text: `🔰 *Current prefix:* \`${config.prefix}\`\n\nUsage: \`.setprefix <character>\`\nExample: \`.setprefix !\`\n\n⚠️ Cannot be a digit (0-9) — those are menu numbers.` });
        }
        if (p.length !== 1) return reply({ text: '❌ Prefix must be exactly one character.' });
        if (/\d/.test(p)) return reply({ text: '❌ Digits (0-9) are reserved for menu replies.' });
        if (/\s/.test(p)) return reply({ text: '❌ Prefix cannot be a space.' });

        const old = config.prefix;
        config.prefix = p;

        try {
            const existing = fs.existsSync(settingsFile)
                ? JSON.parse(fs.readFileSync(settingsFile, 'utf8'))
                : {};
            saveSettings({ ...existing, prefix: p });
        } catch { /* non-fatal — runtime change still works */ }

        await reply({ text: `✅ Prefix changed: \`${old}\` → \`${p}\`\n\nTry: \`${p}menu\`` });
    }
};
