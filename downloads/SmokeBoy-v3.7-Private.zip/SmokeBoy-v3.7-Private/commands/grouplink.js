module.exports = {
    name: 'grouplink',
    aliases: ['glink', 'invite'],
    category: 'group',
    emoji: '🔗',
    description: 'Get the group invite link (admin)',
    groupAdminOnly: true,
    execute: async ({ sock, reply, jid, isGroup, sender }) => {
        if (!isGroup) return reply({ text: '⛔ This command works only in groups.' });

        const meta = await sock.groupMetadata(jid);
        const isSenderAdmin = !!meta.participants.find(p => p.id === sender)?.admin;
        if (!isSenderAdmin) return reply({ text: '⛔ Admin only command.' });

        const code = await sock.groupInviteCode(jid);
        await reply({ text: `🔗 *${meta.subject}*\n\nhttps://chat.whatsapp.com/${code}\n\n⚠️ Share carefully!` });
    }
};
