module.exports = {
    name: 'jid',
    category: 'tools',
    emoji: '🆔',
    description: 'Show this chat JID and your JID',
    execute: async ({ reply, jid, sender, msg }) => {
        const text = `💬 *Chat JID:* ${jid}
👤 *Your JID:* ${sender}
🔢 *Message ID:* ${msg.key.id}
${msg.key.fromMe ? '✅ fromMe (self chat / own device)' : '📨 from other party'}`;
        await reply({ text });
    }
};
