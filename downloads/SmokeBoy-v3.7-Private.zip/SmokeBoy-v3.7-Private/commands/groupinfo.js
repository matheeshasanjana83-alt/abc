module.exports = {
    name: 'groupinfo',
    aliases: ['ginfo', 'gd'],
    category: 'group',
    emoji: 'ℹ️',
    description: 'Show this group info',
    execute: async ({ sock, reply, jid, isGroup }) => {
        if (!isGroup) return reply({ text: '⛔ This command works only in groups.' });

        const meta = await sock.groupMetadata(jid);
        const admins = meta.participants.filter(p => p.admin).length;
        const created = meta.creation ? new Date(meta.creation * 1000).toLocaleDateString('en-GB') : '—';
        const desc = meta.desc ? (meta.desc.length > 300 ? meta.desc.slice(0, 297) + '...' : meta.desc) : '_no description_';

        await reply({
            text: `👥 *${meta.subject}*\n
🆔 \`${meta.id}\`
👤 Owner: ${meta.owner ? '@' + meta.owner.split('@')[0] : '—'}
👑 Admins: ${admins}
🙋 Members: ${meta.participants.length}
📅 Created: ${created}
🔒 Lock: ${meta.restrict ? 'admins only edit info' : 'everyone can edit info'}

📝 *Description:*
${desc}`
        });
    }
};
