module.exports = {
    name: 'ping',
    category: 'tools',
    emoji: '🏓',
    aliases: ['pong', 'speed'],
    description: 'Check latency',
    execute: async ({ reply, send, jid }) => {
        const start = Date.now();
        const sent = await send(jid, { text: '🏓 Pinging...' });
        const latency = Date.now() - start;
        await reply({ text: `🏓 *Pong!*\n\n⏱️ Latency: ${latency}ms\n⚡ Running on Pterodactyl Panel` });
        return sent;
    }
};
