const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { unwrapMessage } = require('../utils');

// downloadMediaMessage calls ctx.logger.info() when it needs to re-upload
// media — a missing logger crashes there, so always pass one.
const quietLogger = { info() {}, warn() {}, error() {}, debug() {}, trace() {}, child() { return this; } };

module.exports = {
    name: 'sticker',
    aliases: ['s', 'take', 'steal'],
    category: 'download',
    emoji: '🖼️',
    description: 'Reply image/video → sticker (.take restyles)',
    execute: async ({ sock, send, msg, jid, args, cmdName, quotedMsg, quotedParticipant, reply }) => {
        const isTake = cmdName === 'take' || cmdName === 'steal';
        const pack = isTake ? (args[0] || 'My Stickers') : 'DL SmokeBoy';
        const author = isTake ? (args[1] || 'by me') : 'ptero-wa-bot';

        // sticker source: the replied message, or this message itself
        let source = null;
        const srcMsg = quotedMsg
            ? { key: { remoteJid: jid, participant: quotedParticipant }, message: unwrapMessage(quotedMsg) }
            : msg;

        const content = unwrapMessage(srcMsg.message || {});
        if (content.imageMessage || content.videoMessage || content.stickerMessage) {
            source = srcMsg;
        }

        if (!source) {
            return reply({
                text: `╭──「 🖼️ STICKER MAKER 」──╮
│
│  1️⃣ Send an image with caption \`.sticker\`
│  2️⃣ Or reply to an image with \`.sticker\`
│
│  🎁 \`.take <pack> <author>\`
│     reply to a sticker → restyle it
│
╰──────────────────╯
⚠️ _Video stickers need ffmpeg on the host —
if video fails, use an image instead._`
            });
        }

        const isVideo = !!content.videoMessage;

        let buffer;
        try {
            buffer = await downloadMediaMessage(source, 'buffer', {}, {
                logger: quietLogger,
                reuploadRequest: sock.updateMediaMessage
            });
        } catch (err) {
            return reply({ text: `❌ Could not download that media.\n\`\`\`${err.message}\`\`\`` });
        }

        try {
            await sock.sendPresenceUpdate('composing', jid);
            const sticker = new Sticker(buffer, {
                pack, author,
                type: StickerTypes.FULL,
                categories: ['🤖', '⚡'],
                quality: 60
            });
            await send(jid, { sticker: await sticker.toBuffer() }, { quoted: msg });
        } catch (err) {
            if (isVideo || /ffmpeg|ffprobe/i.test(err.message)) {
                return reply({
                    text: `⚠️ *Video stickers are not supported on this host*\n(ffmpeg is not installed)\n\n✅ Send an **image** instead — image stickers work fine!`
                });
            }
            throw err; // let the handler report it
        }
    }
};
