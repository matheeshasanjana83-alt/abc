const { jidNormalizedUser } = require('@whiskeysockets/baileys');

module.exports = {
    name: 'demote',
    category: 'group',
    emoji: '⬇️',
    description: 'Remove admin (admin)',
    groupAdminOnly: true,
    botAdminOnly: true,
    execute: async ({ sock, msg, jid, isGroup, sender, target, reply }) => {
        if (!isGroup) return reply({ text: '⛔ This command works only in groups.' });
        if (!target) return reply({ text: '❓ Tag a user or reply to their message.\nUsage: `.demote @user`' });

        const meta = await sock.groupMetadata(jid);
        const isSenderAdmin = !!meta.participants.find(p => p.id === sender)?.admin;
        if (!isSenderAdmin) return reply({ text: '⛔ Admin only command.' });

        const botId = jidNormalizedUser(sock.user.id);
        const isBotAdmin = !!meta.participants.find(p => p.id === botId)?.admin;
        if (!isBotAdmin) return reply({ text: '⛔ I need to be an admin to do that.' });

        const user = jidNormalizedUser(target);
        await sock.groupParticipantsUpdate(jid, [user], 'demote');
        await reply({ text: `⬇️ @${user.split('@')[0]} is no longer an admin`, mentions: [user] });
    }
};
