const axios = require('axios');
const fs = require('fs');
const os = require('os');
const path = require('path');

const UA = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36'
};
const MAX_GB = 10;                 // download cap (user setting)
const MAX_BYTES = MAX_GB * 1024 * 1024 * 1024;
const WHATSAPP_SOFT_LIMIT = 2 * 1024 * 1024 * 1024; // WhatsApp may reject > 2 GB uploads

/** scrape the direct download URL + filename from a mediafire page */
async function scrape(pageUrl) {
    const r = await axios.get(pageUrl, { headers: UA, timeout: 25000, maxRedirects: 5, validateStatus: () => true });

    if (r.status === 404) throw new Error('That file is deleted, blocked or private.');
    if (r.status >= 400) throw new Error(`MediaFire responded ${r.status} — try again later.`);

    const html = String(r.data);

    const dl = html.match(/href="(https?:\/\/download[0-9]*\.mediafire\.com[^"]+)"/)
        || html.match(/"(https:\/\/download[0-9]*\.mediafire\.com[^"]+)"/);
    if (!dl) {
        if (/\/folder\//.test(pageUrl)) throw new Error('Folder links are not supported — send a single file link.');
        throw new Error('No download button found — the file may be private or need login.');
    }

    const filename = (html.match(/<div class="filename">([^<]+)</) || [])[1]?.trim()
        || (html.match(/aria-label="Download file \(([^)]+)\)"/) || [])[1]?.trim();

    return { directUrl: dl[1].replace(/&amp;/g, '&'), pageUrl: r.request?.res?.responseUrl || pageUrl, filename };
}

// ─────────────────── progress message (live editing) ───────────────────
function progressBar(pct) {
    const filled = Math.round((pct / 100) * 12);
    return '▰'.repeat(filled) + '▱'.repeat(12 - filled);
}

function human(bytes) {
    if (bytes >= 1024 * 1024 * 1024) return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB';
    if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB';
    return Math.round(bytes / 1024) + ' KB';
}

function makeEditor(send, jid) {
    let key = null;
    let lastEdit = 0;
    let lastText = '';

    return {
        send: async (text) => {
            const sent = await send(jid, { text });
            key = sent?.key || null;
            return sent;
        },
        update: async (text, force = false) => {
            if (!key || text === lastText) return;
            const now = Date.now();
            if (!force && now - lastEdit < 3000) return; // throttle edits (~every 3s)
            lastEdit = now;
            lastText = text;
            try {
                await send(jid, { text, edit: key });
            } catch { /* edit unsupported/rate-limited — ignore */ }
        },
        hasKey: () => !!key
    };
}

/** stream the file to disk, calling onProgress(loaded, total, speed) */
async function downloadToDisk(url, referer, destPath, onProgress) {
    const res = await axios.get(url, {
        headers: { ...UA, Referer: referer },
        responseType: 'stream', maxRedirects: 5
    });

    const total = parseInt(res.headers['content-length'] || '0', 10);
    if (total && total > MAX_BYTES) throw new Error(`File is ${human(total)} — larger than the ${MAX_GB} GB limit.`);

    const out = fs.createWriteStream(destPath);
    let loaded = 0;
    const started = Date.now();

    await new Promise((resolve, reject) => {
        res.data.on('data', (c) => {
            loaded += c.length;
            if (loaded > MAX_BYTES) {
                res.data.destroy();
                out.destroy();
                reject(new Error(`Download exceeded the ${MAX_GB} GB limit.`));
                return;
            }
            const secs = Math.max((Date.now() - started) / 1000, 0.5);
            onProgress(loaded, total, loaded / secs);
        });
        res.data.on('error', reject);
        out.on('finish', resolve);   // resolve only after the file is fully flushed to disk
        out.on('error', reject);
        res.data.pipe(out);
    });

    return { size: total || loaded, contentType: res.headers['content-type'] || 'application/octet-stream' };
}

module.exports = {
    name: 'mediafire',
    aliases: ['mf', 'mfire'],
    category: 'download',
    emoji: '☁️',
    description: 'MediaFire download — 10GB (.mf <link>)',
    execute: async ({ send, msg, jid, args, reply }) => {
        const url = (args[0] || '').trim();
        if (!/mediafire\.com/i.test(url)) {
            return reply({
                text: `╭──「 ☁️ MEDIAFIRE DL 」──╮
│
│  Usage: \`.mf <mediafire link>\`
│
│  📄 Any public file type
│     (zip, apk, pdf, mp3, ...)
│  📏 Max ${MAX_GB} GB
│  📊 Live progress bar
│  🔗 mediafire.com/file/... links
│
╰──────────────────╯`
            });
        }

        const prog = makeEditor(send, jid);
        await prog.send('⏳ Opening MediaFire page...');

        let info;
        try {
            info = await scrape(url);
        } catch (e) {
            return prog.update(`❌ ${e.message}`, true);
        }

        const name = info.filename || 'mediafire_file';
        const tmpPath = path.join(os.tmpdir(), `wa-mf-${process.pid}-${Date.now().toString(36)}-${name.replace(/[^\w.-]/g, '_')}`);

        let result;
        try {
            result = await downloadToDisk(info.directUrl, info.pageUrl, tmpPath, (loaded, total, speed) => {
                const pct = total ? (loaded / total) * 100 : 0;
                const bar = total ? `${progressBar(pct)} *${pct.toFixed(1)}%*` : progressBar(50);
                const of = total ? `${human(loaded)} / ${human(total)}` : human(loaded);
                const eta = total && speed > 0 ? ` · ⏱️ ${Math.max(1, Math.round((total - loaded) / speed))}s left` : '';
                prog.update(`⬇️ *${name}*\n\n${bar}\n📦 ${of} · ⚡ ${human(speed)}/s${eta}`);
            });
        } catch (e) {
            try { fs.unlinkSync(tmpPath); } catch { }
            return prog.update(`❌ ${e.message}`, true);
        }

        const bigWarning = result.size > WHATSAPP_SOFT_LIMIT
            ? `\n\n⚠️ _Over 2 GB — WhatsApp upload may fail_` : '';
        await prog.update(`✅ Downloaded *${human(result.size)}*\n📤 Uploading to WhatsApp...${bigWarning}`, true);

        try {
            await send(jid, {
                document: { url: tmpPath },
                fileName: name,
                mimetype: result.contentType,
                caption: `☁️ *${name}*\n📦 ${human(result.size)}  |  _MediaFire_`
            }, { quoted: msg });
            await prog.update(`✅ Sent! _${name}_ · ${human(result.size)}`, true);
        } catch (e) {
            await prog.update(`❌ WhatsApp upload failed: ${e.message}`, true);
        } finally {
            try { fs.unlinkSync(tmpPath); } catch { }
        }
    }
};
