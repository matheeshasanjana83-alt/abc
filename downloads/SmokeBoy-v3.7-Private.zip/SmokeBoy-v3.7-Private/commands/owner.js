module.exports = {
    name: 'owner',
    category: 'tools',
    emoji: '👤',
    aliases: ['me', 'profile'],
    description: 'Show owner details',
    execute: async ({ reply, sender, config, msg }) => {
        const isOwner = sender === config.owner;
        const text = `╔══════════════════════════╗
║   👤 *USER INFO*          ║
╚══════════════════════════╝

📱 *Number:* ${sender.split('@')[0]}
🆔 *JID:* ${sender}
💬 *Chat:* ${msg.key.remoteJid}
👑 *Owner:* ${isOwner ? '✅ Yes' : '❌ No'}

💡 This bot is linked to *your* WhatsApp as a
device (like WhatsApp Web). Commands sent in
your own chat work — that is the v3 fix.

⚡ _Pterodactyl Bot Base v3.0_`;
        await reply({ text });
    }
};
