module.exports = {
    name: 'tagall',
    aliases: ['everyone', 'mentionall'],
    category: 'group',
    emoji: '📢',
    description: 'Mention everyone (admin)',
    groupAdminOnly: true,
    execute: async ({ sock, send, msg, jid, isGroup, sender, args, reply }) => {
        if (!isGroup) return reply({ text: '⛔ This command works only in groups.' });

        const meta = await sock.groupMetadata(jid);
        const isSenderAdmin = !!meta.participants.find(p => p.id === sender)?.admin;
        if (!isSenderAdmin) return reply({ text: '⛔ Admin only command.' });

        const extra = args.join(' ');
        const mentions = meta.participants.map(p => p.id);
        const list = meta.participants.map(p =>
            `${p.admin ? (p.admin === 'superadmin' ? '👑' : '🛡️') : '▪️'} @${p.id.split('@')[0]}`
        ).join('\n');

        await send(jid, {
            text: `📢 ${extra ? '*' + extra + '*\n\n' : ''}${list}`,
            mentions
        }, { quoted: msg });
    }
};
