module.exports = {
    name: 'shutdown',
    category: 'settings',
    emoji: '🔴',
    aliases: ['restart'],
    description: 'Stop the bot (panel auto-restarts it)',
    ownerOnly: true,
    execute: async ({ reply, sock }) => {
        await reply({ text: '👋 Shutting down... The panel will restart me.' });
        setTimeout(() => {
            try { sock.end(undefined); } catch { /* ignore */ }
            process.exit(0);
        }, 1000);
    }
};
