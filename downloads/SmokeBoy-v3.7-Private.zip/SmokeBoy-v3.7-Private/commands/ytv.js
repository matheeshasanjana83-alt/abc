const dl = require('../downloader');
const yts = require('yt-search');

// shared YouTube video/audio sender
async function sendYoutube({ reply, send, msg, jid, url, mode, maxMB }) {
    if (!/youtube\.com|youtu\.be/i.test(url || '')) {
        return reply({
            text: `╭──「 ${mode === 'audio' ? '🎧 YT AUDIO' : '🎬 YT VIDEO'} 」──╮
│
│  Usage: \`.yt${mode === 'audio' ? 'a' : 'v'} <youtube url>\`
│
│  📏 video ≤ 60 MB (auto 720→480→360p)
│  🎧 audio ≤ 20 MB (m4a)
│  🔎 \`.play <song name>\` → search + audio
│
╰────────────────────╯`
        });
    }

    await reply({ text: '⏳ Fetching info...' });
    let meta;
    try {
        meta = await dl.info(url);
    } catch (e) {
        return reply({ text: `❌ ${e.message}` });
    }
    const title = (meta.title || '').slice(0, 120);
    const dur = meta.duration ? fmtDur(meta.duration) : '—';
    const channel = meta.uploader || meta.channel || '—';
    await reply({ text: `⬇️ Downloading *${mode === 'audio' ? 'audio' : 'video'}*...\n\n🎬 ${title}\n👤 ${channel}  ⏱️ ${dur}` });

    try {
        const { buffer, ext, via, height } = await dl.download(url, {
            mode,
            maxMB: maxMB || (mode === 'audio' ? 20 : 60)
        });
        const viaNote = via === 'proxy' ? '  |  🌐 via proxy' : '';
        if (mode === 'audio') {
            await send(jid, {
                audio: buffer,
                mimetype: ext === 'mp3' ? 'audio/mpeg' : 'audio/mp4',
                ptt: false,
                caption: `🎧 *${title}*\n👤 ${channel}  |  ⏱️ ${dur}${viaNote}`
            }, { quoted: msg });
        } else {
            await send(jid, {
                video: buffer,
                mimetype: 'video/mp4',
                caption: `🎬 *${title}*\n👤 ${channel}  |  ⏱️ ${dur}${height ? '  |  📺 ' + height + 'p' : ''}${viaNote}`
            }, { quoted: msg });
        }
    } catch (e) {
        return reply({ text: `❌ Download failed: ${e.message}\n\n💡 Long videos may exceed the size limit — try a shorter one, or use \`.yta\` for audio.` });
    }
}

function fmtDur(s) {
    s = Math.round(s);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(sec).padStart(2, '0');
}

// ── .ytv <url> ──
module.exports = {
    name: 'ytv',
    aliases: ['ytvideo', 'video'],
    category: 'download',
    emoji: '🎬',
    description: 'YouTube video download (.ytv <url>)',
    execute: async (ctx) => sendYoutube({ ...ctx, url: ctx.args[0], mode: 'video' })
};

// also export the helper for sibling commands
module.exports.sendYoutube = sendYoutube;
module.exports.fmtDur = fmtDur;
module.exports.yts = yts;
