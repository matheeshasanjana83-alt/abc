const fs = require('fs');
const path = require('path');
const { categories, getCategory, rememberMenu, buildMainMenu, buildCategoryMenu, buildAllMenu } = require('../menudata');

const LOGO = path.join(__dirname, '..', 'logo.png');

function countsFrom(commands) {
    const counts = {};
    for (const c of commands) counts[c.category || 'tools'] = (counts[c.category || 'tools'] || 0) + 1;
    return counts;
}

module.exports = {
    name: 'menu',
    aliases: ['help', 'start', 'commands', 'm'],
    category: 'settings',
    emoji: '📋',
    description: 'Show the main menu',
    execute: async ({ reply, config, args, pushName, commands }) => {
        const counts = countsFrom(commands);
        const mainText = buildMainMenu({
            prefix: config.prefix,
            name: pushName,
            number: (config.owner || '').split('@')[0],
            total: commands.length,
            counts
        });

        // .menu all → everything in one message
        if (args[0] && args[0].toLowerCase() === 'all') {
            const byCat = {};
            for (const c of commands) (byCat[c.category || 'tools'] ||= []).push(c);
            const sent = await reply({ text: buildAllMenu(byCat, config.prefix) });
            rememberMenu(sent?.key?.id);
            return;
        }

        // .menu <number> → open that category directly
        if (/^\d$/.test(args[0] || '') && args[0] !== '0') {
            const cat = getCategory(parseInt(args[0], 10));
            if (!cat) return reply({ text: `❓ No category ${args[0]}. Use ${config.prefix}menu` });
            const cmds = commands.filter(c => c.category === cat.id);
            const sent = await reply({ text: buildCategoryMenu(cat, cmds, config.prefix) });
            rememberMenu(sent?.key?.id);
            return;
        }

        // main menu — as logo image with caption when possible (falls back to text)
        let sent;
        if (fs.existsSync(LOGO)) {
            try {
                sent = await reply({ image: fs.readFileSync(LOGO), caption: mainText, mimetype: 'image/png' });
            } catch { sent = undefined; }
        }
        if (!sent) sent = await reply({ text: mainText });
        rememberMenu(sent?.key?.id);
    }
};
