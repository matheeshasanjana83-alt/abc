const axios = require('axios');

const MAX_ZIP = 80 * 1024 * 1024; // keep it WhatsApp-friendly

function parseRepo(input) {
    if (!input) return null;
    // full url: https://github.com/user/repo(.git)(/tree/branch/...)
    const m = input.match(/github\.com\/([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)/i);
    if (m) return { owner: m[1], repo: m[2].replace(/\.git$/, '') };
    // shorthand: user/repo
    const s = input.trim().match(/^([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)$/);
    if (s) return { owner: s[1], repo: s[2] };
    return null;
}

module.exports = {
    name: 'gitclone',
    aliases: ['repo', 'github'],
    category: 'download',
    emoji: '🐙',
    description: 'GitHub repo → zip (.gitclone user/repo)',
    execute: async ({ send, msg, jid, args, reply }) => {
        const parsed = parseRepo(args[0]);
        if (!parsed) {
            return reply({
                text: `╭──「 🐙 GITHUB REPO ZIP 」──╮
│
│  Usage:
│  \`.gitclone user/repo\`
│  \`.gitclone https://github.com/user/repo\`
│
│  📦 Sends the repo as a .zip file
│  📏 Max ~80 MB
│
╰─────────────────────╯`
            });
        }

        const { owner, repo } = parsed;
        await reply({ text: `⏳ Fetching *${owner}/${repo}* ...` });

        const meta = await axios.get(`https://api.github.com/repos/${owner}/${repo}`, {
            headers: { 'User-Agent': 'PteroWA-Bot', 'Accept': 'application/vnd.github+json' },
            timeout: 20000,
            validateStatus: () => true
        });

        if (meta.status === 404) return reply({ text: `❌ Repo *${owner}/${repo}* not found (or private).` });
        if (meta.status >= 400) return reply({ text: `❌ GitHub API error ${meta.status}` });

        const branch = meta.data.default_branch;
        const stars = meta.data.stargazers_count ?? 0;
        const lang = meta.data.language || '—';
        const desc = meta.data.description ? (meta.data.description.slice(0, 150)) : '_no description_';

        // NOTE: GitHub's "size" includes full git history, but the codeload
        // zip is only the branch snapshot — usually much smaller. The
        // maxContentLength cap on the download below protects us.

        try {
            const zip = await axios.get(
                `https://codeload.github.com/${owner}/${repo}/zip/refs/heads/${branch}`,
                { responseType: 'arraybuffer', timeout: 120000, maxContentLength: MAX_ZIP }
            );

            await send(jid, {
                document: Buffer.from(zip.data),
                fileName: `${repo}-${branch}.zip`,
                mimetype: 'application/zip',
                caption: `🐙 *${owner}/${repo}*\n🌿 Branch: \`${branch}\`  |  ⭐ ${stars}  |  💻 ${lang}\n📝 ${desc}`
            }, { quoted: msg });
        } catch (err) {
            const why = /maxContentLength|larger than/i.test(String(err.message))
                ? 'the zip is bigger than 80 MB' : 'download failed';
            return reply({ text: `❌ Sorry, ${why}.\n\n🔗 https://github.com/${owner}/${repo}/archive/refs/heads/${branch}.zip` });
        }
    }
};
