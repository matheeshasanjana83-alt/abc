const axios = require('axios');
const fs = require('fs');
const os = require('os');
const path = require('path');

// streams to disk (no RAM limit). Default cap 2 GB (WhatsApp document limit). Override with DL_MAX_MB env.
const MAX_BYTES = (parseInt(process.env.DL_MAX_MB || '2000', 10)) * 1024 * 1024;
const human = (b) => b >= 1073741824 ? (b / 1073741824).toFixed(2) + ' GB' : b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB';

function pickName(headers, finalUrl, fallbackUrl) {
    const cd = headers['content-disposition'] || '';
    let m = cd.match(/filename\*\s*=\s*(?:UTF-8'')?"?([^";]+)"?/i) || cd.match(/filename\s*=\s*"?([^";]+)"?/i);
    if (m) { try { return decodeURIComponent(m[1]); } catch { return m[1]; } }
    for (const u of [finalUrl, fallbackUrl]) {
        try { const n = decodeURIComponent(new URL(u).pathname.split('/').pop() || ''); if (n) return n; } catch { }
    }
    return 'file';
}

module.exports = {
    name: 'download',
    aliases: ['dl', 'fetch'],
    category: 'download',
    emoji: '⬇️',
    description: 'Direct link → file (.download <url>) up to 2GB',
    execute: async ({ send, msg, jid, args, reply }) => {
        const url = (args[0] || '').trim();
        if (!/^https?:\/\//i.test(url)) {
            return reply({ text: `⬇️ *Direct Downloader*\n\nUsage: \`.download <direct-url>\`\n\nAny file: zip, apk, images, video, audio, PDF\nMax: ${human(MAX_BYTES)}  |  direct links only\n(MediaFire → \`.mf\`, YouTube → \`.ytv\` / \`.yta\`)` });
        }
        await reply({ text: '⏳ Downloading...' });

        const tmp = path.join(os.tmpdir(), `wa-dl-${process.pid}-${Date.now().toString(36)}`);
        try {
            const res = await axios.get(url, {
                responseType: 'stream', timeout: 60000, maxRedirects: 10,
                headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36' },
                validateStatus: () => true
            });
            if (res.status >= 400) { res.data.destroy(); return reply({ text: `❌ Server responded ${res.status} (link එක expire වෙලා හෝ private)` }); }

            const ct = String(res.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
            const finalUrl = res.request?.res?.responseUrl || url;
            if (ct === 'text/html') {
                res.data.destroy();
                return reply({ text: `❌ මේ link එකෙන් එන්නේ *web page* එකක්, file එකක් නෙවෙයි.\n\nDirect download link එකක් එවන්න (GitHub raw, litterbox, MediaFire → \`.mf\`).` });
            }
            const total = parseInt(res.headers['content-length'] || '0', 10);
            if (total > MAX_BYTES) { res.data.destroy(); return reply({ text: `❌ File is ${human(total)} — larger than ${human(MAX_BYTES)}.` }); }

            let loaded = 0;
            await new Promise((resolve, reject) => {
                const out = fs.createWriteStream(tmp);
                res.data.on('data', (c) => {
                    loaded += c.length;
                    if (loaded > MAX_BYTES) { res.data.destroy(); out.destroy(); reject(new Error(`larger than ${human(MAX_BYTES)}`)); }
                });
                res.data.on('error', reject);
                out.on('error', reject);
                out.on('finish', resolve);
                res.data.pipe(out);
            });

            const filename = pickName(res.headers, finalUrl, url);
            const caption = `✅ ${filename} (${human(loaded)})`;
            const mt = ct || 'application/octet-stream';
            let content;
            if (loaded < 16 * 1048576 && ['image/jpeg', 'image/png', 'image/webp'].includes(ct)) content = { image: { url: tmp }, mimetype: ct, caption };
            else if (loaded < 64 * 1048576 && ct.startsWith('video/')) content = { video: { url: tmp }, mimetype: ct, caption };
            else if (loaded < 64 * 1048576 && ct.startsWith('audio/')) content = { audio: { url: tmp }, mimetype: ct, ptt: false };
            else content = { document: { url: tmp }, mimetype: mt, fileName: filename, caption };

            await send(jid, content, { quoted: msg });
        } catch (err) {
            await reply({ text: `❌ Download failed: ${String(err.message).slice(0, 150)}` });
        } finally {
            fs.rm(tmp, { force: true }, () => { });
        }
    }
};
