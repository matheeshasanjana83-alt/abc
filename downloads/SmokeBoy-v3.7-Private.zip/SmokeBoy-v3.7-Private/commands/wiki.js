const axios = require('axios');

const UA = { 'User-Agent': 'SmokeBoy/3.4 (WhatsApp bot; +https://github.com)' };
const SINHALA_RE = /[\u0D80-\u0DFF]/;

async function wikiSummary(lang, title) {
    const url = `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, '_'))}`;
    const r = await axios.get(url, { headers: UA, timeout: 15000, validateStatus: () => true });
    return r;
}

async function searchSuggest(lang, query) {
    const r = await axios.get(`https://${lang}.wikipedia.org/w/rest.php/v1/search/page`, {
        params: { q: query, limit: 3 },
        headers: UA, timeout: 15000, validateStatus: () => true
    });
    if (r.status >= 400 || !r.data?.pages) return [];
    return r.data.pages.map(p => ({ title: p.title, desc: (p.excerpt || '').replace(/<[^>]+>/g, '') }));
}

module.exports = {
    name: 'wiki',
    aliases: ['wikipedia'],
    category: 'download',
    emoji: '📚',
    description: 'Wikipedia summary (.wiki <topic>)',
    execute: async ({ send, msg, jid, args, reply }) => {
        const raw = args.join(' ').trim();
        if (!raw) {
            return reply({
                text: `╭──「 📚 WIKIPEDIA 」──╮
│
│  \`.wiki <topic>\`  → English
│  \`.wiki si <මාතෘකාව>\` → සිංහල
│  (සිංහල text auto-detect වෙනවා)
│
╰────────────────╯
💡 Example: \`.wiki Sri Lanka\``
            });
        }

        let lang = 'en';
        let query = raw;
        const m = raw.match(/^(si|en|ta|hi)\s+(.+)$/i);
        if (m) { lang = m[1].toLowerCase(); query = m[2]; }
        else if (SINHALA_RE.test(raw)) lang = 'si';

        await reply({ text: `⏳ Searching Wikipedia (${lang}) ...` });

        let r = await wikiSummary(lang, query);

        // not found → try search suggestions
        if (r.status === 404 || (r.status === 200 && !r.data?.extract)) {
            const sugg = await searchSuggest(lang, query);
            if (sugg.length) {
                // try the top suggestion directly
                r = await wikiSummary(lang, sugg[0].title);
                if (r.status !== 200 || !r.data?.extract) {
                    return reply({
                        text: `❓ Nothing exact found for *"${query}"*.\n\nDid you mean:\n${sugg.map((s, i) => `${i + 1}. ${s.title}`).join('\n')}\n\n💡 \`.wiki ${sugg[0].title}\``
                    });
                }
            } else {
                return reply({ text: `❓ Nothing found on Wikipedia for *"${query}"*.` });
            }
        }

        if (r.status >= 400) return reply({ text: `❌ Wikipedia error ${r.status}` });

        const d = r.data;
        const title = d.title || query;
        const extract = (d.extract || '').slice(0, 1200);
        const link = d.content_urls?.mobile?.page || d.content_urls?.desktop?.page || `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(title)}`;

        const text = `📚 *${title}*${d.description ? `\n_${d.description}_` : ''}

${extract}

🔗 ${link}`;

        // if there is a thumbnail image → send image with caption
        const thumb = d.originalimage?.source || d.thumbnail?.source;
        if (thumb) {
            try {
                const img = await axios.get(thumb, {
                    responseType: 'arraybuffer', timeout: 20000,
                    maxContentLength: 8 * 1024 * 1024, headers: UA
                });
                return await send(jid, {
                    image: Buffer.from(img.data),
                    caption: text + '\n\n📷 _Wikipedia_'
                }, { quoted: msg });
            } catch { /* fall back to text */ }
        }
        await reply({ text });
    }
};
