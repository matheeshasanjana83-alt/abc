const { sendYoutube } = require('./ytv');

module.exports = {
    name: 'yta',
    aliases: ['ytaudio', 'song'],
    category: 'download',
    emoji: '🎧',
    description: 'YouTube audio download (.yta <url>)',
    execute: async (ctx) => sendYoutube({ ...ctx, url: ctx.args[0], mode: 'audio' })
};
