const { jidNormalizedUser } = require('@whiskeysockets/baileys');

module.exports = {
    name: 'kick',
    aliases: ['remove', 'ban'],
    category: 'group',
    emoji: '👢',
    description: 'Remove a member (admin)',
    groupAdminOnly: true,
    botAdminOnly: true,
    execute: async ({ sock, msg, jid, isGroup, sender, target, reply }) => {
        if (!isGroup) return reply({ text: '⛔ This command works only in groups.' });
        if (!target) return reply({ text: '❓ Tag a user or reply to their message.\nUsage: `.kick @user`' });

        const meta = await sock.groupMetadata(jid);
        const isSenderAdmin = !!meta.participants.find(p => p.id === sender)?.admin;
        if (!isSenderAdmin) return reply({ text: '⛔ Admin only command.' });

        const botId = jidNormalizedUser(sock.user.id);
        const isBotAdmin = !!meta.participants.find(p => p.id === botId)?.admin;
        if (!isBotAdmin) return reply({ text: '⛔ I need to be an admin to do that.' });

        const victim = jidNormalizedUser(target);
        if (victim === botId) return reply({ text: '😂 I am not kicking myself!' });
        if (victim === jidNormalizedUser(meta.owner)) return reply({ text: '⛔ Cannot remove the group owner.' });

        await sock.groupParticipantsUpdate(jid, [victim], 'remove');
        await reply({ text: `👢 Removed @${victim.split('@')[0]}`, mentions: [victim] });
    }
};
