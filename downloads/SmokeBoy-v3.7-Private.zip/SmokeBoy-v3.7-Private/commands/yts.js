const yts = require('yt-search');

module.exports = {
    name: 'yts',
    aliases: ['ytsearch', 'search'],
    category: 'download',
    emoji: '🔎',
    description: 'YouTube search (.yts <query>)',
    execute: async ({ reply, args, prefix }) => {
        const query = args.join(' ').trim();
        if (!query) return reply({ text: `🔎 *YouTube Search*\n\nUsage: \`${prefix}yts <query>\`\nExample: \`${prefix}yts baileys tutorial\`` });

        const r = await yts(query);
        const videos = (r.videos || []).slice(0, 5);
        if (!videos.length) return reply({ text: `😢 No results for "${query}"` });

        const list = videos.map((v, i) => {
            const title = v.title.length > 60 ? v.title.slice(0, 57) + '...' : v.title;
            const views = v.views ? (v.views / 1e6).toFixed(1) + 'M' : '—';
            return `${i + 1}️⃣ *${title}*\n    ⏱️ ${v.timestamp || '—'}  |  👁️ ${views} views\n    🔗 ${v.url}`;
        }).join('\n\n');

        await reply({ text: `🔎 *YouTube — "${query}"*\n\n${list}\n\n⚙️ _top ${videos.length} results_` });
    }
};
