const { sendYoutube, yts } = require('./ytv');

module.exports = {
    name: 'play',
    aliases: ['song2', 'playsong'],
    category: 'download',
    emoji: '▶️',
    description: 'Search & play a song (.play <name>)',
    execute: async (ctx) => {
        const query = ctx.args.join(' ').trim();
        if (!query) {
            return ctx.reply({
                text: `╭──「 ▶️ PLAY 」──╮
│
│  Usage: \`.play <song name>\`
│  Example: \`.play faded alan walker\`
│
│  🔎 Searches YouTube, downloads audio
│
╰──────────────╯`
            });
        }

        await ctx.reply({ text: `🔎 Searching *${query}* ...` });
        const r = await yts(query);
        const video = (r.videos || []).find(v => (v.seconds || 0) <= 600); // ≤ 10 min
        if (!video) return ctx.reply({ text: `😢 No good result for *${query}* (only long videos found).` });

        return sendYoutube({ ...ctx, url: video.url, mode: 'audio', maxMB: 25 });
    }
};
