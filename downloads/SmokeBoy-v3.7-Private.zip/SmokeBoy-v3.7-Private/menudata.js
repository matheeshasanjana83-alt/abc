/**
 * Menu system — Project DL SmokeBoy
 *
 * User-friendly features:
 *  - main menu can be sent as logo image + caption (falls back to text)
 *  - categories show command counts
 *  - reply navigation: 1-4 = category, 9 = all commands, 0 = main menu
 *  - invalid numbers get a helpful hint instead of silence
 *  - bilingual hints (English + Sinhala)
 */

const MENU_TTL = 15 * 60 * 1000; // menu replies valid for 15 minutes
const menuIds = new Map();       // messageId -> timestamp sent

function rememberMenu(id) {
    if (!id) return;
    const now = Date.now();
    for (const [k, ts] of menuIds) if (now - ts > MENU_TTL) menuIds.delete(k);
    menuIds.set(id, now);
}

function isMenuMessage(id) {
    if (!id || !menuIds.has(id)) return false;
    const fresh = Date.now() - menuIds.get(id) <= MENU_TTL;
    if (fresh) menuIds.set(id, Date.now());
    return fresh;
}

// ─────────────────────────── categories ───────────────────────────
const categories = [
    { id: 'download', no: 1, emoji: '📥', name: 'Download Menu' },
    { id: 'tools',    no: 2, emoji: '🛠️', name: 'Tools' },
    { id: 'group',    no: 3, emoji: '👥', name: 'Group Management' },
    { id: 'settings', no: 4, emoji: '⚙️', name: 'Bot Settings' }
];

const numberEmoji = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];

function getCategory(n) { return categories.find(c => c.no === n) || null; }

// ─────────────────────────── rendering ────────────────────────────
function cmdLine(cmd, prefix) {
    const e = cmd.emoji ? cmd.emoji + ' ' : '';
    const lock = cmd.ownerOnly ? ' 👑' : '';
    return `│  ${e}${prefix}${cmd.name}${lock}\n│     ➜ ${cmd.description || ''}`;
}

const BRAND = `🔥 𝗣𝗥𝗢𝗝𝗘𝗖𝗧 𝗗𝗟 𝗦𝗠𝗢𝗞𝗘𝗕𝗢𝗬 ⬇️`;

function buildMainMenu({ prefix, name, number, total, counts }) {
    const who = name || 'friend';
    return (
`${BRAND}
_Downloader × Tools × Groups_

👋 Hi *${who}*!
📱 ${number || '—'} · 🔰 Prefix \`${prefix}\` · 🧩 ${total} commands

╭──「 🗂️ CATEGORIES 」──╮
│
${categories.map(c => `│  ${numberEmoji[c.no - 1]} ${c.emoji} *${c.name}* · ${counts?.[c.id] ?? 0}`).join('\n')}
│
╰──────────────────╯

╭──「 ⚡ QUICK USE 」──╮
│
│  ▶️ ${prefix}play <song name>
│  🎬 ${prefix}ytv <youtube url>
│  📘 ${prefix}fb <facebook url>
│  🎵 ${prefix}tiktok <tiktok url>
│
╰──────────────────╯

💡 Reply *1-4* → open category
🔢 Reply *9* → all commands
🏠 Reply *0* → back to main menu

📌 *ලබා ගන්න ඕන category එකේ අංකය*
    *මේ message එකට reply කරලා* type කරන්න! 🇱🇰`
    );
}

function buildCategoryMenu(cat, cmds, prefix) {
    const list = cmds.length
        ? cmds.map(c => cmdLine(c, prefix)).join('\n│\n')
        : '│  🈳 nothing here yet';
    return (
`${cat.emoji} *${cat.name.toUpperCase()}*
╭──「 ${numberEmoji[cat.no - 1]} 0${cat.no}/4 · ${cmds.length} commands 」──╮
│
${list}
│
╰────────────────────╯

🏠 Reply *0* → main menu
🔢 Reply *1-4* → category · *9* → all
💡 Command එක type කරලා use කරන්න`
    );
}

function buildAllMenu(cmdsByCat, prefix) {
    return categories.map(cat => {
        const cmds = cmdsByCat[cat.id] || [];
        if (!cmds.length) return null;
        return `${cat.emoji} *${cat.name.toUpperCase()}*\n╭───❪ ${numberEmoji[cat.no - 1]} ❫───╮\n│\n${cmds.map(c => cmdLine(c, prefix)).join('\n│\n')}\n│\n╰${'─'.repeat(20)}╯`;
    }).filter(Boolean).join('\n\n') + `\n\n🏠 Reply *0* → main menu · Reply *1-4* → category`;
}

/** helpful reply when the user sends a number that isn't a valid target */
function buildNavHint() {
    return `❓ Hmm, that number isn't a menu item.\n\n💡 Reply *1-4* → category\n🔢 Reply *9* → all commands\n🏠 Reply *0* → main menu`;
}

module.exports = {
    categories, numberEmoji,
    rememberMenu, isMenuMessage,
    getCategory, buildMainMenu, buildCategoryMenu, buildAllMenu, buildNavHint
};
