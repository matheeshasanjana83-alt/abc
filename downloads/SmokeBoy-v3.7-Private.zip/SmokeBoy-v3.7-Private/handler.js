/**
 * Command handler.
 *
 * v3.1:
 *  - numbered category menu (menudata.js): replying to a menu message with
 *    a number opens that category — works without any prefix
 *  - ctx now includes quoted message info + reply-target (for sticker,
 *    kick, promote/demote etc.)
 *  - supports commands from self chat ("Message Yourself" => fromMe),
 *    groups and normal DMs
 */

const fs = require('fs');
const path = require('path');
const { isMenuMessage, getCategory, buildCategoryMenu, buildMainMenu, buildAllMenu, buildNavHint, rememberMenu } = require('./menudata');
const { unwrapMessage, extractText, jidNormalized } = require('./utils');

const commands = new Map();
const commandsPath = path.join(__dirname, 'commands');

function loadCommands() {
    commands.clear();
    if (!fs.existsSync(commandsPath)) fs.mkdirSync(commandsPath, { recursive: true });
    for (const file of fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'))) {
        try {
            delete require.cache[require.resolve(path.join(commandsPath, file))];
            const cmd = require(path.join(commandsPath, file));
            if (cmd.name && typeof cmd.execute === 'function') {
                commands.set(cmd.name, cmd);
                for (const a of (cmd.aliases || [])) commands.set(a, cmd);
            }
        } catch (e) {
            console.log(`[Handler] Error loading ${file}: ${e.message}`);
        }
    }
    return commands;
}

loadCommands();

function commandList() {
    return [...new Map([...commands.values()].map(c => [c.name, c])).values()];
}

async function messageHandler(sock, msg, config, send) {
    const jid = msg.key.remoteJid;
    if (!jid) return;

    // ignore broadcasts / newsletters / status
    if (jid === 'status@broadcast' || jid.endsWith('@broadcast') || jid.endsWith('@newsletter')) return;

    const isGroup = jid.endsWith('@g.us');
    if (isGroup && !config.allowGroups) return;

    // In groups the sender is the participant; in DMs it's the remote jid;
    // in the self chat it is your own jid (fromMe === true there).
    const sender = (isGroup ? msg.key.participant : jid) || jid;

    const text = extractText(msg.message);
    if (!text) return;

    // quoted message info (for menu navigation + sticker/kick/promote)
    const m = unwrapMessage(msg.message);
    const contextInfo = m.extendedTextMessage?.contextInfo || m.imageMessage?.contextInfo || m.videoMessage?.contextInfo || {};
    const quotedMsg = contextInfo.quotedMessage || null;
    const quotedParticipant = contextInfo.participant || null;
    const target = contextInfo.mentionedJid?.[0] || quotedParticipant || null;

    // Owner check (computed early so PRIVATE mode also covers menu replies)
    const isSelfChat = jidNormalized(jid) === jidNormalized(config.owner);
    const isOwner = msg.key.fromMe === true || isSelfChat || (!!config.owner && jidNormalized(sender) === jidNormalized(config.owner));
    if (config.ownerOnly && !isOwner) return;   // PRIVATE: silently ignore everyone else

    // ── Reply-based MENU NAVIGATION ─────────────────────────────────
    // If this message replies to one of our sent menus AND the body is a
    // single digit, navigate: 1-4 category, 9 all, 0 main. No prefix needed.
    if (contextInfo.stanzaId && isMenuMessage(contextInfo.stanzaId) && /^\d$/.test(text)) {
        const n = parseInt(text, 10);
        const commandsAll = commandList();
        const counts = {};
        for (const c of commandsAll) counts[c.category || 'tools'] = (counts[c.category || 'tools'] || 0) + 1;

        if (n === 0) {
            // back to main menu (text-only for speed)
            const sent = await send(jid, {
                text: buildMainMenu({
                    prefix: config.prefix,
                    name: msg.pushName || null,
                    number: (config.owner || '').split('@')[0],
                    total: commandsAll.length,
                    counts
                })
            }, { quoted: msg });
            rememberMenu(sent?.key?.id);
        } else if (n === 9) {
            const byCat = {};
            for (const c of commandsAll) (byCat[c.category || 'tools'] ||= []).push(c);
            const sent = await send(jid, { text: buildAllMenu(byCat, config.prefix) }, { quoted: msg });
            rememberMenu(sent?.key?.id);
        } else {
            const cat = getCategory(n);
            if (cat) {
                const cmds = commandsAll.filter(c => c.category === cat.id);
                const sent = await send(jid, { text: buildCategoryMenu(cat, cmds, config.prefix) }, { quoted: msg });
                rememberMenu(sent?.key?.id);
            } else {
                // helpful hint instead of silence
                await send(jid, { text: buildNavHint() }, { quoted: msg });
            }
        }
        return;
    }

    // ── Normal command processing ───────────────────────────────────
    const p = config.prefix;
    if (!text.startsWith(p)) return;

    const args = text.slice(p.length).trim().split(/\s+/);
    const cmdName = (args.shift() || '').toLowerCase();
    if (!cmdName) return;

    const command = commands.get(cmdName);
    if (!command) return;

    if (command.ownerOnly && !isOwner) {
        await send(jid, { text: '⛔ Owner only command.' }, { quoted: msg });
        return;
    }

    const ctx = {
        sock, send, msg, jid, sender, isGroup, isOwner, args,
        config, prefix: p, cmdName,
        commands: commandList(),
        quotedMsg, quotedParticipant, target,
        pushName: msg.pushName || null,
        reply: (content) => send(jid, content, { quoted: msg })
    };

    try {
        await command.execute(ctx);
    } catch (err) {
        console.error(`[Command Error] ${cmdName}:`, err);
        await send(jid, { text: `❌ Error: ${err.message}` }, { quoted: msg });
    }
}

module.exports = messageHandler;
module.exports.loadCommands = loadCommands;
module.exports.getCommands = commandList;

