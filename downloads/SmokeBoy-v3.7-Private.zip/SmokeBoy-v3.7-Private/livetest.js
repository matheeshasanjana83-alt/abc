// Live end-to-end test of the new download commands (real APIs, mock WhatsApp)
const tiktok = require('./commands/tiktok');
const gitclone = require('./commands/gitclone');
const wiki = require('./commands/wiki');
const dl = require('./commands/download');

const calls = [];
const sock = {
    sendMessage: async (jid, content) => { calls.push(content); return { key: { id: 'X' + calls.length } }; },
    sendPresenceUpdate: async () => {}
};
const jid = '94771234567@s.whatsapp.net';
const ctxBase = {
    sock, send: sock.sendMessage, jid,
    msg: { key: { id: 'A', remoteJid: jid, fromMe: true } },
    reply: async (c) => { calls.push(c); return { key: { id: 'X' + calls.length } }; }
};
const mb = (buf) => Math.round(buf.length / 1024 / 1024 * 10) / 10 + 'MB';

(async () => {
    // ── TikTok real URL ──
    calls.length = 0;
    await tiktok.execute({ ...ctxBase, args: ['https://www.tiktok.com/@tiktok/video/7106594312292453675'] });
    const ttVideo = calls.find(c => c.video);
    console.log('TikTok:', ttVideo ? '✅ video ' + mb(ttVideo.video) + ' | caption @author: ' + /@/.test(ttVideo.caption || '') : '❌', '| audio:', calls.some(c => c.audio) ? '✅' : '—');

    // ── TikTok invalid input → usage ──
    calls.length = 0;
    await tiktok.execute({ ...ctxBase, args: ['not-a-url'] });
    console.log('TikTok usage msg:', calls.some(c => /TIKTOK DOWNLOADER/.test(c.text || '')) ? '✅' : '❌');

    // ── GitClone real repo ──
    calls.length = 0;
    await gitclone.execute({ ...ctxBase, args: ['WhiskeySockets/Baileys'] });
    const doc = calls.find(c => c.document);
    console.log('GitClone:', doc ? '✅ zip ' + mb(doc.document) + ' | ' + doc.fileName : '❌', '| caption:', (doc?.caption || '').split('\n')[0]);

    // ── GitClone 404 repo ──
    calls.length = 0;
    await gitclone.execute({ ...ctxBase, args: ['user/definitely-not-real-xyz-123'] });
    console.log('GitClone 404:', calls.some(c => /not found/.test(c.text || '')) ? '✅' : '❌');

    // ── Wiki EN ──
    calls.length = 0;
    await wiki.execute({ ...ctxBase, args: ['Sri', 'Lanka'] });
    const w = calls.find(c => c.image || (c.text && /Sri Lanka/.test(c.text)));
    console.log('Wiki EN:', w ? '✅ ' + (w.image ? 'image+caption' : 'text') : '❌');

    // ── Wiki SI (Sinhala auto-detect) ──
    calls.length = 0;
    await wiki.execute({ ...ctxBase, args: ['ශ්\u200dරී ලංකාව'] });
    const wsi = calls.find(c => c.image || (c.text && /ලංක/.test(c.text)));
    console.log('Wiki SI:', wsi ? '✅ ' + (wsi.image ? 'image+caption' : 'text') : '❌');

    // ── Wiki typo → suggestions ──
    calls.length = 0;
    await wiki.execute({ ...ctxBase, args: ['sri', 'lnkaa'] });
    console.log('Wiki typo fallback:', calls.some(c => /(Did you mean|Nothing found)/.test(c.text || '')) ? '✅' : '❌');

    // ── .download real image URL ──
    calls.length = 0;
    await dl.execute({ ...ctxBase, args: ['https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png'] });
    const img = calls.find(c => c.image);
    console.log('Download image:', img ? '✅ ' + mb(img.image) : '❌');

    // ── .download usage ──
    calls.length = 0;
    await dl.execute({ ...ctxBase, args: [] });
    console.log('Download usage msg:', calls.some(c => /Media Downloader/.test(c.text || '')) ? '✅' : '❌');
})();
