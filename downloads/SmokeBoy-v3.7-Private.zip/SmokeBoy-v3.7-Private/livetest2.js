// Live E2E test: .yta / .ytv / .fb through the real downloader module
const ytv = require('./commands/ytv');
const yta = require('./commands/yta');
const fb = require('./commands/fb');
const play = require('./commands/play');

const calls = [];
const sock = {
    sendMessage: async (jid, content) => { calls.push(content); return { key: { id: 'X' + calls.length } }; },
    sendPresenceUpdate: async () => {}
};
const jid = '94771234567@s.whatsapp.net';
const mkCtx = (args) => ({
    sock, send: sock.sendMessage, jid, args,
    msg: { key: { id: 'A', remoteJid: jid, fromMe: true } },
    reply: async (c) => { calls.push(c); return { key: { id: 'X' + calls.length } }; }
});
const mb = (buf) => Math.round(buf.length / 1024 / 1024 * 10) / 10 + 'MB';
const findMedia = () => calls.find(c => c.audio || c.video);

(async () => {
    // usage messages (no URL)
    calls.length = 0;
    await ytv.execute(mkCtx([]));
    console.log('ytv usage:', calls.some(c => /YT VIDEO/.test(c.text || '')) ? '✅' : '❌');
    calls.length = 0;
    await fb.execute(mkCtx([]));
    console.log('fb usage:', calls.some(c => /FACEBOOK DL/.test(c.text || '')) ? '✅' : '❌');
    calls.length = 0;
    await play.execute(mkCtx([]));
    console.log('play usage:', calls.some(c => /PLAY/.test(c.text || '')) ? '✅' : '❌');

    // ── .ytv real video (Me at the zoo — 19 seconds) ──
    calls.length = 0;
    await ytv.execute(mkCtx(['https://www.youtube.com/watch?v=jNQXAC9IVRw']));
    const vid = findMedia();
    console.log('ytv zoo:', vid?.video ? `✅ ${mb(vid.video)} ${vid.caption.split('\n')[0]}` : '❌ ' + JSON.stringify(calls[calls.length - 1]?.text || '').slice(0, 150));

    // ── .yta real audio ──
    calls.length = 0;
    await yta.execute(mkCtx(['https://www.youtube.com/watch?v=jNQXAC9IVRw']));
    const aud = findMedia();
    console.log('yta zoo:', aud?.audio ? `✅ ${mb(aud.audio)} ${aud.caption.split('\n')[0]}` : '❌ ' + JSON.stringify(calls[calls.length - 1]?.text || '').slice(0, 150));

    // ── .play search + download ──
    calls.length = 0;
    await play.execute(mkCtx(['me at the zoo']));
    const played = findMedia();
    console.log('play:', played?.audio ? `✅ ${mb(played.audio)}` : '❌ ' + JSON.stringify(calls[calls.length - 1]?.text || '').slice(0, 150));

    // ── .fb real facebook video ──
    calls.length = 0;
    await fb.execute(mkCtx(['https://www.facebook.com/facebook/videos/10153231379946729/']));
    const fbv = findMedia();
    console.log('fb:', fbv?.video ? `✅ ${mb(fbv.video)} ${fbv.caption.split('\n')[0]}` : '❌ ' + JSON.stringify(calls[calls.length - 1]?.text || '').slice(0, 150));

    // ── size-cap fallback: 720p of a long video should drop to 480/360 or error nicely ──
    calls.length = 0;
    await ytv.execute(mkCtx(['https://www.youtube.com/watch?v=aqz-KE-bpKQ']));
    const big = findMedia();
    console.log('ytv size-cap fallback (10min video):', big?.video ? `✅ ${mb(big.video)} ${/p/.test(big.caption) ? '(auto lower quality)' : ''}` : 'ℹ️ refused with message: ' + (calls[calls.length - 1]?.text || '').slice(0, 100));

    const dl = require('./downloader');
    console.log('downloader status:', JSON.stringify(dl.status()));
    process.exit(0);
})();
