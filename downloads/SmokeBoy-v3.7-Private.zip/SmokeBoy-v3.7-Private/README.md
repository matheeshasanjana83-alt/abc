# Project DL SmokeBoy v3.7 (Private) 🔒

## v3.7 වෙනස්කම් (Arena agent)
| # | ප්‍රශ්නය | Fix |
|---|---|---|
| 1 | `ownerOnly: false` — ඔයා ඉන්න ඕනෑම group එකක / DM එකක ඕනෑම කෙනෙක්ට ඔයාගේ account එකෙන් commands run කරන්න පුළුවන් වුණා (menu number replies ද) | **Private mode default** — commands වැඩ කරන්නේ ඔයාට (paired number) විතරයි. අනිත් අයව නිහඬව ignore කරයි (reply එකක්වත් නෑ). Public කරන්න ඕන නම් env `PUBLIC_MODE=true` |
| 2 | `.download` 40 MB limit + මුළු file එකම RAM එකට | Disk එකට stream කරයි, **2 GB** දක්වා (`DL_MAX_MB` env එකෙන් වෙනස් කරන්න පුළුවන්). HEAD request යවන්නේ නෑ — x0.at වගේ links වැඩ |
| 3 | `.download` web page link එකක් (gofile/mega page) දුන්නම HTML file එකක් එව්වා | "web page එකක්" කියලා පැහැදිලි error එකක් |
| 4 | `filename*=` (UTF-8) filenames read වුණේ නෑ | Fixed |
| 5 | `.mf` — file එක disk එකට flush වෙන්න කලින් send කරන්න පුළුවන් වුණා (corrupt/කෙටි file) | stream `finish` වෙනකම් බලා ඉන්නවා |

Tests: `npm test` → 33/33 pass (private-mode tests 5ක් අලුතෙන්).
Security review: malware / session exfiltration නෑ. Xray/yt-dlp/ffmpeg download වෙන්නේ නිල GitHub releases වලින් විතරයි.

---

## (පරණ README) Project DL SmokeBoy 🔥

Pterodactyl Panel එකක් සඳහා සාදන ලද WhatsApp Bot — WhatsApp Web multi-device protocol (Baileys) එක භාවිත කරයි. Browser එකක් අවශ්‍ය නොවේ.

## v2 එකේ Replies නොආපු හේතුව (THE BUG)

v2 `index.js` එකේ:

```js
sock.ev.on('messages.upsert', async (m) => {
    for (const msg of m.messages) {
        if (msg.key.fromMe) continue;   // ← මෙය තමයි ප්‍රධාන වැරද්ද
        ...
    }
});
```

Bot එක link වෙන්නේ **ඔයාගේම WhatsApp account එකට** (WhatsApp Web වගේ linked device එකක්).
ඔයා ඔයාගේම number එකට ("Message Yourself" chat එකට) `.menu` ගහන විට ඒ message එක
`fromMe: true` විදිහට තමයි එන්නේ. ඒ නිසා handler එක ඒ සියලු commands නොසලකා හැරියා — replies ආවේ නෑ.

**v3 fix:** `fromMe` messages process කරයි, නමුත් bot එකම යැවූ messages (`sentIds` එකේ track කරයි) skip කරයි — loop වෙන්නේ නෑ.

### අනෙකුත් fixes
| # | v2 ප්‍රශ්නය | v3 fix |
|---|-----------|--------|
| 1 | `fromMe` messages skip — self-chat commands වැඩ කළේ නෑ | fromMe process + sent-id loop guard |
| 2 | `getMessage()` empty message return කළා | recent-message cache එකෙන් ඇත්ත message එක |
| 3 | viewOnce/ephemeral/caption wrappers read කළේ නෑ | full unwrap + text extraction |
| 4 | Pairing 428 error එකක් ආවම මැරුණා | 428 → 3s පසු retry |
| 5 | `connectionReplaced` (440) වලදී නිහඬව හැංගුණා | clear message + exit (panel restart කරයි) |
| 6 | loggedOut වලදී session එක හැංගිලා තිබුණා | session delete → clean re-pair |
| 7 | Terminal prompt එකක් මිස code එකක් නෑ (env) | `WA_PHONE_NUMBER` env var support |

## Pterodactyl Setup

1. **Egg:** Node.js egg එකක් (Node JS Generic / "Node.js VM" egg) භාවිත කරන්න. Node >= 18.
2. Files upload කරන්න (zip එක upload කර archive එක unzip කරන්න — `auth_info_baileys` folder එක නැති වෙන්න බලාපොරොත්තු වන්න).
3. **Startup command:** `npm start`  (මුල් වරට: `npm install && npm start`)
   - Egg "Additional Node Packages" field එකට: `@whiskeysockets/baileys@6.7.24 @hapi/boom pino qrcode-terminal` දාන්නත් පුළුවන් — auto install වෙනවා.
4. **Variables (optional):**
   - `WA_PHONE_NUMBER` = 94771234567 (country code + number, + හෝ spaces නැතුව) — මෙය දැමූ විට terminal prompt එක අවශ්‍ය නෑ, pairing code එක console එකේ එන ගමන් පෙනේවි.
   - `BOT_NAME` = ඔයාගේ bot නම, `BOT_PREFIX` = `.`
5. **Start** කරන්න → console එකේ 8-digit pairing code එක පෙනේවි.
6. Phone එකේ: **WhatsApp → Settings → Linked Devices → Link a Device → "Link with phone number instead"** → code එක දාන්න.
7. සම්බන්ධ වූ විගස ඔයාට ඔයාගේම chat එකට "✅ online" message එකක් එයි. `.menu` ගහලා test කරන්න.

### Re-pair කරන්න ඕන නම්
- Panel file manager එකෙන් `auth_info_baileys` folder එක delete කර restart කරන්න.
- Phone එකෙන් bot device එක remove කළොත් bot එක automatic restart වී re-pair mode එකට යයි.

## Commands & Menu System

`.menu` එක category menu එකක් පෙන්වයි. **Menu message එකට reply කරලා number එකක් type කළාම ඒ category එකේ commands open වෙනව෋** (0 = main menu). `.menu 1` … `.menu 4` සහ `.menu all` භාවිත කරන්නත් පුළුවන්.

| # | Category | Commands |
|---|---|---|
| 1️⃣ | 📥 Download Menu | `.mf <link>` (MediaFire file — 10GB, live progress), `.ytv <url>` (YouTube video), `.yta <url>` (YouTube audio), `.play <name>` (song search + download), `.fb <url>` (Facebook video), `.tiktok <url>` (no-watermark + audio), `.yts <query>` (YouTube search), `.sticker`, `.take`, `.gitclone user/repo`, `.wiki <topic>` (සිංහල OK), `.download <url>` |
| 2️⃣ | 🛠️ Tools | `.ping`, `.owner`, `.jid`, `.echo <text>` |
| 3️⃣ | 👥 Group Management | `.groupinfo`, `.tagall`, `.kick @user`, `.promote @user`, `.demote @user`, `.grouplink` (admin commands) |
| 4️⃣ | ⚙️ Bot Settings | `.menu`, `.info`, `.setprefix <char>` 👑, `.shutdown` 👑 |

### YouTube / Facebook downloader ක්‍රියාත්මක වන ආකාරය
- **yt-dlp + ffmpeg** binaries පළමු download එකේදීම `bin/` folder එකට **auto-download** වේ (කලින් install කරන්න දෙයක් නෑ)
- Direct connection එක block වූවොත් (YouTube sign-in wall) **V2Ray proxy fallback** එක auto enable වේ
- **V2RAY_SUB_URL** env variable එකට subscription URL එකක් (හෝ `vmess://`/`vless://` link එකක්) දමන්න
- Server expire වී මැරුණොත් **auto-rotate** — ඊළඟ server එකට යයි. සියල්ලම මැරුණොත් subscription එක **auto re-fetch** වී අලුත් configs ගනී
- උදාහරණයක්: `V2RAY_SUB_URL=https://raw.githubusercontent.com/Epodonios/v2ray-configs/main/All_Configs_Sub.txt`

අලුත් command එකක් එකතු කරන්න: `commands/` folder එකට `.js` file එකක් දාන්න — `category` field එකෙන් menu එකට auto add වෙනවා:
```js
module.exports = {
    name: 'hello',
    aliases: ['hi'],
    category: 'tools',        // download | tools | group | settings
    emoji: '👋',
    description: 'Say hello',
    execute: async ({ reply }) => { await reply({ text: '👋 Ayubowan!' }); }
};
```

## ⚠️ වැදගත්
- මෙය WhatsApp Terms of Service එකට එරෙහි unofficial method එකක්. WhatsApp account **ban** වීමේ අවදානමක් තියෙනවා — ප්‍රධාන number එකක නොව අවදානම් භාරගත් තැනක test කරන්න. Spam/bulk messages එක්ක තියාගන්න එපා.
- WhatsApp protocol එක නිතර වෙනස් වෙනවා — Baileys version එක update කරන්න ඕන වෙනවිට වෙනවිට ඇති.

## Tech

- **Baileys 6.7.24** — WhatsApp Web protocol reverse-engineering library: `wss://web.whatsapp.com/ws/chat` WebSocket → Noise_XX handshake (Curve25519) → Signal protocol encryption (sessions + SenderKey groups) → protobuf message nodes (`iq`, `message`, `receipt`...).
- Pairing code = phone number එකට server එකෙන් 8-digit code එකක් (5 random bytes Crockford-base32 encoded — web.whatsapp.com එකේ "Link with phone number instead" feature එකම ය).
