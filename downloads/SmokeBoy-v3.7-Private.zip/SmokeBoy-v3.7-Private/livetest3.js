// Live E2E test: MediaFire with live progress editing
const mf = require('./commands/mediafire');
const fs = require('fs');

const calls = [];
const sock = {
    // hook: record + verify the temp file exists when the document is sent
    sendMessage: async (jid, content) => {
        calls.push(content);
        if (content.document?.url) calls.fileExistedAtSend = fs.existsSync(content.document.url);
        return { key: { id: 'MSG-' + calls.length, remoteJid: jid, fromMe: true } };
    },
    sendPresenceUpdate: async () => { }
};
const jid = '94771234567@s.whatsapp.net';
const mkCtx = (args) => ({
    sock, send: sock.sendMessage, jid, args,
    msg: { key: { id: 'A', remoteJid: jid, fromMe: true } },
    reply: async (c) => { calls.push(c); return { key: { id: 'MSG-' + calls.length } }; }
});

(async () => {
    // 1. usage message
    calls.length = 0;
    await mf.execute(mkCtx([]));
    console.log('usage msg (10GB):', calls.some(c => /Max 10 GB/.test(c.text || '')) ? '✅' : '❌');

    // 2. dead link → edited error
    calls.length = 0;
    await mf.execute(mkCtx(['https://www.mediafire.com/file/zgru6wj660fe6c1/Mod.zip/file']));
    const last = calls[calls.length - 1];
    console.log('dead link edit:', /deleted|blocked|private/.test(last?.text || '') ? '✅ (via edit: ' + (!!last?.edit) + ')' : '❌');

    // 3. real download with progress
    calls.length = 0;
    await mf.execute(mkCtx(['http://www.mediafire.com/file/i81ypgwy95bczkd/AccountEdge_Pro_v13.zip']));

    const edits = calls.filter(c => c.edit);
    const progressEdits = edits.filter(c => /⬇️/.test(c.text || ''));
    const doneEdit = edits.find(c => /Downloaded/.test(c.text || ''));
    const sentEdit = edits.find(c => /Sent!/.test(c.text || ''));
    const doc = calls.find(c => c.document);

    console.log('progress edits fired:', progressEdits.length >= 1 ? '✅ ' + progressEdits.length + ' edit(s)' : 'ℹ️ 0 (file downloaded in <3s — throttle skips)', );
    if (progressEdits.length) {
        console.log('   sample:', progressEdits[0].text.split('\n').map(l => l.trim()).filter(Boolean).slice(0, 3).join(' | ').slice(0, 110));
    }
    console.log('completion edit:', doneEdit ? '✅ ' + doneEdit.text.split('\n')[0] : '❌');
    console.log('sent confirmation edit:', sentEdit ? '✅' : '❌');
    console.log('document sent:', doc ? `✅ file=${doc.fileName}, temp-file-exists-at-send=${calls.fileExistedAtSend}, caption=${doc.caption.split('\n')[0]}` : '❌');

    // temp file cleaned up?
    const leftovers = fs.readdirSync(require('os').tmpdir()).filter(f => f.startsWith('wa-mf-'));
    console.log('temp cleanup:', leftovers.length === 0 ? '✅' : '❌ ' + leftovers.join(', '));

    process.exit(0);
})();
