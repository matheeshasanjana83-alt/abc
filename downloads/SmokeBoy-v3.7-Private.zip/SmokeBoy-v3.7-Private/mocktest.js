/**
 * Mock test — proves the v3 self-chat fix + v3.1 menu system.
 * 1. Self-chat commands (fromMe = true) get replies — the v2 killer bug
 * 2. Category menu: .menu, .menu <n>, .menu all
 * 3. Reply-to-menu navigation with a bare number
 */
const OWN_JID = '94771234567@s.whatsapp.net';

// wipe persisted prefix from any earlier run
const fs = require('fs');
if (fs.existsSync(__dirname + '/botsettings.json')) fs.unlinkSync(__dirname + '/botsettings.json');

const config = require('./config');
config.owner = OWN_JID;

const messageHandler = require('./handler');
const { isMenuMessage } = require('./menudata');

// mock socket
let idCounter = 0;
const sent = [];
const sock = {
    user: { id: OWN_JID, name: 'Test' },
    sendMessage: async (jid, content, opts) => {
        sent.push({ jid, content, quoted: !!opts?.quoted, id: 'MSG-' + (++idCounter) });
        return { key: { id: 'MSG-' + idCounter, remoteJid: jid, fromMe: true } };
    },
    sendPresenceUpdate: async () => {},
    groupMetadata: async (jid) => ({
        id: jid, subject: 'Test Group', owner: OWN_JID, creation: 1700000000, desc: 'test',
        participants: [
            { id: OWN_JID, admin: 'superadmin' },
            { id: '94770001111@s.whatsapp.net', admin: null },
            { id: '94770002222@s.whatsapp.net', admin: 'admin' }
        ]
    }),
    groupInviteCode: async () => 'AbCdEfG123',
    groupParticipantsUpdate: async () => []
};
const send = sock.sendMessage;

function makeMsg(text, extra = {}) {
    return {
        key: {
            id: extra.id || 'IN-' + Math.random().toString(36).slice(2, 8),
            remoteJid: extra.jid || OWN_JID,
            fromMe: extra.fromMe !== undefined ? extra.fromMe : true,
            participant: extra.participant
        },
        pushName: extra.pushName || 'Kasun',
        message: extra.message
            || (extra.contextInfo
                ? { extendedTextMessage: { text, contextInfo: extra.contextInfo } }
                : { conversation: text })
    };
}

(async () => {
    let pass = 0, fail = 0;
    const t = (name, cond) => { cond ? (pass++, console.log('  ✅', name)) : (fail++, console.log('  ❌', name)); };

    // ── basic command flow ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('.menu'), config, send);
    t('self-chat .menu replies', sent.length === 1);
    const mainMenu = sent[0];
    const mainText = mainMenu.content.caption || mainMenu.content.text || '';
    t('main menu sent as logo image + caption', !!mainMenu.content.image && /CATEGORIES/.test(mainText));
    t('main menu shows all 4 categories with counts',
        /Download Menu\* · \d+/.test(mainText) && /Tools\* · \d+/.test(mainText) &&
        /Group Management\* · \d+/.test(mainText) && /Bot Settings\* · \d+/.test(mainText));
    t('main menu has SmokeBoy branding + greeting + Sinhala hint',
        /𝗣𝗥𝗢𝗝𝗘𝗖𝗧 𝗗𝗟 𝗦𝗠𝗢𝗞𝗘𝗕𝗢𝗬/.test(mainText) && /Kasun/.test(mainText) && /reply කරලා/.test(mainText));
    t('menu message id registered for navigation', isMenuMessage(mainMenu.id));

    // ── reply to menu with a number → category opens ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('1', { contextInfo: { stanzaId: mainMenu.id, quotedMessage: { conversation: '.menu' } } }), config, send);
    t('reply "1" opens Download Menu', sent.length === 1 && /DOWNLOAD MENU/.test(sent[0].content.text) && /sticker/.test(sent[0].content.text));

    sent.length = 0;
    await messageHandler(sock, makeMsg('3', { contextInfo: { stanzaId: mainMenu.id } }), config, send);
    t('reply "3" opens Group Management', sent.length === 1 && /GROUP MANAGEMENT/.test(sent[0].content.text) && /tagall/.test(sent[0].content.text));

    // ── reply "9" → all commands ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('9', { contextInfo: { stanzaId: mainMenu.id } }), config, send);
    t('reply "9" shows all categories', sent.length === 1 &&
        /DOWNLOAD MENU/.test(sent[0].content.text) && /TOOLS/.test(sent[0].content.text) &&
        /GROUP MANAGEMENT/.test(sent[0].content.text) && /BOT SETTINGS/.test(sent[0].content.text));

    // ── reply invalid number "5" → helpful hint ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('5', { contextInfo: { stanzaId: mainMenu.id } }), config, send);
    t('reply "5" gets helpful hint', sent.length === 1 && /isn't a menu item|Reply \*1-4\*/.test(sent[0].content.text));

    // ── category menu reply "0" → back to main ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('0', { contextInfo: { stanzaId: mainMenu.id } }), config, send);
    t('reply "0" returns to main menu (text version)', sent.length === 1 && !!sent[0].content.text && /CATEGORIES/.test(sent[0].content.text));

    // ── .menu <number> direct ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('.menu 2'), config, send);
    t('.menu 2 opens Tools', sent.length === 1 && /TOOLS/.test(sent[0].content.text) && /ping/.test(sent[0].content.text));

    sent.length = 0;
    await messageHandler(sock, makeMsg('.menu 4'), config, send);
    t('.menu 4 opens Bot Settings', sent.length === 1 && /BOT SETTINGS/.test(sent[0].content.text) && /setprefix/.test(sent[0].content.text));

    // ── .menu all ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('.menu all'), config, send);
    t('.menu all shows every category', sent.length === 1 &&
        /DOWNLOAD/.test(sent[0].content.text) && /TOOLS/.test(sent[0].content.text) &&
        /GROUP MANAGEMENT/.test(sent[0].content.text) && /BOT SETTINGS/.test(sent[0].content.text));

    // ── non-number reply to menu is ignored ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('hello', { contextInfo: { stanzaId: mainMenu.id } }), config, send);
    t('text reply to menu ignored', sent.length === 0);

    // ── number WITHOUT menu quote does nothing ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('2'), config, send);
    t('bare number without menu reply ignored', sent.length === 0);

    // ── setprefix (owner only) ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('.setprefix !'), config, send);
    t('.setprefix works', sent.length === 1 && /changed/.test(sent[0].content.text) && config.prefix === '!');
    const persisted = JSON.parse(fs.readFileSync(__dirname + '/botsettings.json', 'utf8'));
    t('prefix persisted to botsettings.json', persisted.prefix === '!');

    // prefix actually changed for parsing
    sent.length = 0;
    await messageHandler(sock, makeMsg('!ping'), config, send);
    t('new prefix ! works for commands', sent.length >= 1 && /Pong/.test(sent[sent.length - 1].content.text));
    sent.length = 0;
    await messageHandler(sock, makeMsg('.ping'), config, send);
    t('old prefix . ignored', sent.length === 0);

    // restore prefix
    config.prefix = '.';
    if (fs.existsSync(__dirname + '/botsettings.json')) fs.unlinkSync(__dirname + '/botsettings.json');

    // ── regression: core v3 tests ──
    sent.length = 0;
    await messageHandler(sock, makeMsg('.ping'), config, send);
    t('self-chat .ping replies', sent.length >= 1 && /Pong/.test(sent[sent.length - 1].content.text));

    sent.length = 0;
    await messageHandler(sock, makeMsg('.yts'), config, send);
    t('.yts without query shows usage', sent.length === 1 && /YouTube Search/.test(sent[0].content.text));

    sent.length = 0;
    await messageHandler(sock, makeMsg('.echo ayubowan'), config, send);
    t('.echo works', sent.length === 1 && sent[0].content.text === 'ayubowan');

    const GROUP = '12036302@g.us';
    const ADMIN = '94770002222@s.whatsapp.net'; // admin in mock metadata
    // ── PRIVATE mode (default): other people are silently ignored ──
    t('private mode is ON by default', config.ownerOnly === true);
    sent.length = 0;
    await messageHandler(sock, makeMsg('.ping', { jid: '94770009999@s.whatsapp.net', fromMe: false }), config, send);
    t('private: stranger DM .ping ignored (no reply)', sent.length === 0);
    sent.length = 0;
    await messageHandler(sock, makeMsg('.menu', { jid: GROUP, fromMe: false, participant: ADMIN }), config, send);
    t('private: group member .menu ignored', sent.length === 0);
    sent.length = 0;
    await messageHandler(sock, makeMsg('1', { jid: '94770009999@s.whatsapp.net', fromMe: false, contextInfo: { stanzaId: mainMenu.id } }), config, send);
    t('private: stranger menu-number reply ignored', sent.length === 0);
    sent.length = 0;
    await messageHandler(sock, makeMsg('.ping', { jid: GROUP, fromMe: true, participant: OWN_JID }), config, send);
    t('private: owner .ping inside a group works', sent.length >= 1 && sent.some(x => /Pong/.test(x.content.text || '')));

    // ── group commands (PUBLIC mode) ──
    config.ownerOnly = false;

    sent.length = 0;
    await messageHandler(sock, makeMsg('.groupinfo', { jid: GROUP, fromMe: false, participant: ADMIN }), config, send);
    t('group .groupinfo works', sent.length === 1 && /Test Group/.test(sent[0].content.text));

    sent.length = 0;
    await messageHandler(sock, makeMsg('.tagall', { jid: GROUP, fromMe: false, participant: ADMIN }), config, send);
    t('group .tagall mentions everyone', sent.length === 1 &&
        sent[0].content.mentions?.length === 3 && /@94771234567/.test(sent[0].content.text));

    sent.length = 0;
    await messageHandler(sock, makeMsg('.tagall', { jid: GROUP, fromMe: false, participant: '94770001111@s.whatsapp.net' }), config, send);
    t('non-admin .tagall blocked', sent.length === 1 && /Admin only/.test(sent[0].content.text));

    sent.length = 0;
    await messageHandler(sock, makeMsg('.kick', {
        jid: GROUP, fromMe: false, participant: ADMIN,
        contextInfo: { mentionedJid: ['94770001111@s.whatsapp.net'] }
    }), config, send);
    t('group .kick with mention works', sent.length === 1 && /Removed/.test(sent[0].content.text));

    sent.length = 0;
    await messageHandler(sock, makeMsg('.grouplink', { jid: GROUP, fromMe: false, participant: ADMIN }), config, send);
    t('group .grouplink works', sent.length === 1 && /chat\.whatsapp\.com\/AbCdEfG123/.test(sent[0].content.text));

    sent.length = 0;
    await messageHandler(sock, makeMsg('.groupinfo'), config, send); // DM
    t('groupinfo blocked in DM', sent.length === 1 && /only in groups/.test(sent[0].content.text));

    console.log(`\n${fail === 0 ? '🎉 ALL TESTS PASSED' : '⚠️  FAILURES'}: ${pass} passed, ${fail} failed`);
    process.exit(fail === 0 ? 0 : 1);
})();
