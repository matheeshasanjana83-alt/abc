/** Shared helpers — no circular dependencies */

/** Pull the actual content out of wrapper messages (viewOnce, ephemeral, ...) */
function unwrapMessage(message) {
    let m = message;
    for (let i = 0; i < 5 && m; i++) {
        if (m.ephemeralMessage) m = m.ephemeralMessage.message;
        else if (m.viewOnceMessage) m = m.viewOnceMessage.message;
        else if (m.viewOnceMessageV2) m = m.viewOnceMessageV2.message;
        else if (m.viewOnceMessageV2Extension) m = m.viewOnceMessageV2Extension.message;
        else if (m.documentWithCaptionMessage) m = m.documentWithCaptionMessage.message;
        else if (m.editedMessage) m = m.editedMessage.message;
        else break;
    }
    return m || {};
}

/** Extract readable text from any message type */
function extractText(message) {
    const m = unwrapMessage(message);
    return (
        m.conversation ||
        m.extendedTextMessage?.text ||
        m.imageMessage?.caption ||
        m.videoMessage?.caption ||
        m.documentMessage?.caption ||
        m.buttonsResponseMessage?.selectedButtonId ||
        m.listResponseMessage?.singleSelectReply?.selectedRowId ||
        ''
    ).trim();
}

function jidNormalized(jid) {
    return String(jid || '').split(':')[0];
}

module.exports = { unwrapMessage, extractText, jidNormalized };
