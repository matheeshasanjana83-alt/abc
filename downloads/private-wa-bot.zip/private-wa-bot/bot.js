// Private WhatsApp bot - owner only (Baileys). Commands: .ping  .download <url>
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

const OWNER = '94XXXXXXXXX'; // <-- ඔයාගේ WhatsApp number එක (94 න් පටන් ගන්න, + නැතුව, 0 නැතුව)

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState(path.join(__dirname, 'auth'));
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({ version, auth: state, logger: pino({ level: 'silent' }), printQRInTerminal: false });
  sock.ev.on('creds.update', saveCreds);

  if (!sock.authState.creds.registered) {
    setTimeout(async () => {
      const code = await sock.requestPairingCode(OWNER);
      console.log('\n>>> Pairing code: ' + code + '  (WhatsApp > Linked devices > Link with phone number)\n');
    }, 3000);
  }

  sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
    if (connection === 'open') console.log('Bot connected ✅');
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code === DisconnectReason.loggedOut) console.log('Logged out. auth folder එක delete කරලා ආයෙත් run කරන්න.');
      else setTimeout(start, 3000);
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    const m = messages[0];
    if (!m?.message || !m.key.fromMe) return;          // ඔයා යවන messages විතරයි -> private
    const jid = m.key.remoteJid;
    const text = (m.message.conversation || m.message.extendedTextMessage?.text || '').trim();
    if (!text.startsWith('.')) return;

    if (text === '.ping') return sock.sendMessage(jid, { text: 'pong ✅' }, { quoted: m });

    if (text.startsWith('.download ')) {
      const url = text.slice(10).trim();
      await sock.sendMessage(jid, { text: '⏳ Downloading...' }, { quoted: m });
      const tmp = path.join(__dirname, 'dl_' + Date.now());
      try {
        const res = await fetch(url, { redirect: 'follow', headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 14)' } });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const type = res.headers.get('content-type') || 'application/octet-stream';
        if (type.startsWith('text/html')) throw new Error('මේ link එකෙන් එන්නේ web page එකක්, file එකක් නෙවෙයි (direct link නෙවෙයි)');
        let name = decodeURIComponent(path.basename(new URL(res.url).pathname)) || 'file';
        const cd = res.headers.get('content-disposition');
        const mm = cd && cd.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
        if (mm) name = decodeURIComponent(mm[1]);
        await pipeline(Readable.fromWeb(res.body), fs.createWriteStream(tmp));
        const mb = (fs.statSync(tmp).size / 1048576).toFixed(2);
        await sock.sendMessage(jid, { document: { url: tmp }, fileName: name, mimetype: type, caption: `✅ ${name} (${mb} MB)` }, { quoted: m });
      } catch (e) {
        await sock.sendMessage(jid, { text: '❌ Error: ' + e.message }, { quoted: m });
      } finally {
        fs.rmSync(tmp, { force: true });
      }
    }
  });
}
start();
