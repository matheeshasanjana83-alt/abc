Joystick Layout (CLEO නැතුව) v1
================================
මේක CLEO script එකක් නෙවෙයි. Game එකේම තියෙන "Adjustable.cfg" file එක පාවිච්චි කරනවා.
Game එක පටන් ගනිද්දී controls default file එක load කරලා, ඊට පස්සේ මේ file එක උඩින් load කරනවා
(libGTASA: CTouchInterface::LoadTouchControls -> LoadFromFile("Adjustable.cfg", 0)).

Folders:
  1 - Small        : පොඩි joystick
  2 - Default      : game එකේ original size එක
  3 - Large        : ලොකු
  4 - Extra Large  : ගොඩක් ලොකු
  5 - Custom       : ඔයාටම අංක වෙනස් කරලා ඕනෑම තැනකට / ඕනෑම size එකකට දාන්න

දාන විදිය:
1. ඕනේ folder එකේ තියෙන Adjustable.cfg එක copy කරන්න.
2. ඒක SAVE FILES (GTASAsf1.b, GTASAsf2.b ...) තියෙන folder එකටම දාන්න.
   (සාමාන්‍යයෙන් .../com.rockstargames.gtasa/files/ folder එක)
   !! එතන දැනටමත් Adjustable.cfg එකක් තියෙනවා නම් replace කරන්න එපා
      (ඒකේ ඔයාගේ buttons layout එක තියෙනවා).
      ඒ වෙනුවට මේ file එකේ "PositionAndScale ..." පේළි 2 ඒ file එකේ අන්තිමට එකතු කරන්න.
3. Game එක Force stop කරලා open කරන්න.

Custom (5) එක edit කරන හැටි (text editor එකකින්):
  PositionAndScale  X  Y  W  H ; WIDGET_POSITION_THUMB_CIRCLE   <- joystick රවුම
  PositionAndScale  X  Y  W  H ; WIDGET_POSITION_PED_MOVE       <- touch කරන්න පුළුවන් ප්‍රදේශය
  X = වමේ ඉඳන් දකුණට (0 ... 640)
  Y = උඩ ඉඳන් පහළට (0 ... 448)
  W H = size එක (වැඩි කළොත් ලොකුයි, අඩු කළොත් පොඩියි)
  Joystick එක ගෙනියන තැනට පේළි දෙකේම X Y එකට සමානව වෙනස් කරන්න.
  පේළියේ "SCALE_" කියන වචනය දාන්න එපා.

සැලකිය යුතුයි:
- "Joystick Fixed ..." / "Joystick Move Mode" CLEO scripts මේකත් එක්ක එකට පාවිච්චි කරන්න එපා
  (ඒවාත් joystick එක වෙනස් කරන නිසා ගැටෙනවා). ඒ scripts start කරන්නෙ නැතුව ඉන්න.
- Settings -> Adjust Controls එකෙන් save කළොත් game එක Adjustable.cfg එක අලුතෙන් ලියනවා.
  එතකොට joystick පේළි 2 නැති වෙන්න පුළුවන්. එහෙම වුණොත් ආයෙත් එකතු කරන්න.
- නැවත original එකට: Adjustable.cfg එකේ joystick පේළි 2 මකන්න.
- Code එකෙන් තහවුරු කරගත්තා, හැබැයි phone එකේ තවම test කරලා නෑ.
